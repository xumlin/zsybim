package com.hnbits.app.system.logic;


import com.hnbits.app.system.vo.TbBusinessConfigVo;
import java.util.List;

public abstract interface IConfigLogic
{
  public abstract TbBusinessConfigVo queryConfigById(String paramString)
    throws Exception;
  
  public abstract long queryConfig(TbBusinessConfigVo paramTbBusinessConfigVo)
    throws Exception;
  
  public abstract List<TbBusinessConfigVo> queryConfigList(TbBusinessConfigVo paramTbBusinessConfigVo, Integer paramInteger1, Integer paramInteger2)
    throws Exception;
  
  public abstract int insertConfig(TbBusinessConfigVo paramTbBusinessConfigVo)
    throws Exception;
  
  public abstract int deleteConfig(String paramString)
    throws Exception;
  
  public abstract int updateConfig(TbBusinessConfigVo paramTbBusinessConfigVo)
    throws Exception;

 public abstract List<TbBusinessConfigVo> queryConfigByInfo(String param_code)
	throws Exception;;
}

/* Location:           C:\maven\repo\com\hnbits\webcore\3.2.7-SNAPSHOT\webcore-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.app.system.logic.IConfigLogic
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */