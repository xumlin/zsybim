package com.hnbits.app.system.action;

/*     */ 
/*     */ import com.hnbits.app.BaseAction;
/*     */ import com.hnbits.app.system.logic.IConfigLogic;
/*     */ import com.hnbits.app.system.vo.TbBusinessConfigVo;
/*     */ import com.hnbits.util.MsgUtil;
/*     */ import com.hnbits.util.SpringHttpUtil;
/*     */ import com.hnbits.util.StringUtil;
/*     */ import com.hnbits.util.easyui.GridJsonUtil;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Controller
/*     */ @RequestMapping({"admin/configAction"})
/*     */ public class ConfigAction
/*     */   extends BaseAction
/*     */ {
/*  36 */   private static final Logger log = LoggerFactory.getLogger(ConfigAction.class);
/*     */   @Autowired(required=false)
/*     */   private IConfigLogic configLogic;
/*     */   
/*     */   public ConfigAction() {}
/*     */   
/*  42 */   private String EDIT_Config_INIT_JSP_PATH = "jsp/system/configEdit";
/*     */   
/*  44 */   private String DETAIL_Config_INIT_JSP_PATH = "jsp/system/configDetail";

/*  44 */   private String INDEX_Config_INIT_JSP_PATH = "jsp/index/updateInfo";
/*     */   
/*     */   @RequestMapping({"queryAll.do"})
/*     */   @ResponseBody
/*     */   public String queryAll() {
/*  49 */     log.info("开始查询系统参数配置!");
/*  50 */     String str = null;
/*  51 */     List<TbBusinessConfigVo> list = null;
/*  52 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/*     */     try {
/*  54 */       String page = req.getParameter("page");
/*  55 */       String size = req.getParameter("rows");
/*  56 */       TbBusinessConfigVo vo = new TbBusinessConfigVo();
/*  57 */       String param_code = req.getParameter("param_code");
/*  58 */       if (!StringUtil.isEmpty(param_code))
/*  59 */         vo.setParam_code(param_code);
/*  60 */       String param_name = req.getParameter("param_name");
/*  61 */       if (!StringUtil.isEmpty(param_name))
/*  62 */         vo.setParam_name(param_name);
/*  63 */       String param_val = req.getParameter("param_val");
/*  64 */       if (!StringUtil.isEmpty(param_val))
/*  65 */         vo.setParam_val(param_val);
/*  66 */       if ((!StringUtil.isEmpty(page)) && (!StringUtil.isEmpty(size))) {
/*  67 */         long rows = this.configLogic.queryConfig(vo);
/*  68 */         list = this.configLogic.queryConfigList(vo, Integer.valueOf(Integer.parseInt(page)), Integer.valueOf(Integer.parseInt(size)));
/*  69 */         str = GridJsonUtil.getDataGridJson(rows, list);
/*     */       }
/*     */       else {
/*  72 */         list = this.configLogic.queryConfigList(vo, null, null);
/*  73 */         str = GridJsonUtil.getDataGridJson(list.size(), list);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  77 */       e.printStackTrace();
/*     */     }
/*  79 */     log.debug(str);
/*  80 */     log.info("结束查询系统参数配置,返回记录数[" + (list == null ? "null" : Integer.valueOf(list.size())) + "]!");
/*  81 */     return str;
/*     */   }
/*     */   
/*     */   @RequestMapping({"add.do"})
/*     */   @ResponseBody
/*     */   public String add() {
/*  87 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/*  88 */     String msg = null;
/*     */     try {
/*  90 */       TbBusinessConfigVo vo = (TbBusinessConfigVo)SpringHttpUtil.getParameterVo(req, TbBusinessConfigVo.class, Boolean.valueOf(false));
/*  91 */       int rows = this.configLogic.insertConfig(vo);
/*  92 */       if (rows > 0) {
/*  93 */         msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("common.action.addOK"));
/*     */       }
/*     */       else {
/*  96 */         msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.action.addFail"));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 100 */       e.printStackTrace();
/* 101 */       msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.action.addFail"));
/*     */     }
/* 103 */     log.debug(msg);
/* 104 */     return msg;
/*     */   }
/*     */   
/*     */   @RequestMapping({"init.do"})
/*     */   public String init() throws Exception {
/* 109 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/* 110 */     String type = req.getParameter("type");
/* 111 */     String param_code = req.getParameter("param_code");
/* 112 */     TbBusinessConfigVo vo = this.configLogic.queryConfigById(param_code);
/* 113 */     req.setAttribute("data", vo);
/* 114 */     if ((!StringUtil.isEmpty(type)) && (type.equalsIgnoreCase("view"))) {
/* 115 */       return this.DETAIL_Config_INIT_JSP_PATH;
/*     */     }else if((!StringUtil.isEmpty(type)) && (type.equalsIgnoreCase("index"))) {
				return this.INDEX_Config_INIT_JSP_PATH;
				}
/*     */     
/* 118 */     return this.EDIT_Config_INIT_JSP_PATH;
/*     */   }
/*     */   
/*     */   @RequestMapping({"update.do"})
/*     */   @ResponseBody
/*     */   public String update()
/*     */   {
/* 125 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/* 126 */     String msg = null;
/*     */     try {
/* 128 */       TbBusinessConfigVo vo = (TbBusinessConfigVo)SpringHttpUtil.getParameterVo(req, TbBusinessConfigVo.class, Boolean.valueOf(false));
/* 129 */       int rows = this.configLogic.updateConfig(vo);
/* 130 */       if (rows > 0) {
/* 131 */         msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("common.action.updateOK"));
/*     */       }
/*     */       else {
/* 134 */         msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.action.updateFail"));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 138 */       e.printStackTrace();
/* 139 */       msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.exception"));
/*     */     }
/* 141 */     log.debug(msg);
/* 142 */     return msg;
/*     */   }
/*     */   
/*     */   @RequestMapping({"delete.do"})
/*     */   @ResponseBody
/*     */   public String delete() {
/* 148 */     String msg = null;
/* 149 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/*     */     try {
/* 151 */       String param_code = req.getParameter("ids");
/*     */       
/* 153 */       int rows = this.configLogic.deleteConfig(param_code);
/* 154 */       if (rows > 0) {
/* 155 */         msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("common.action.deleteOK"));
/*     */       }
/*     */       else {
/* 158 */         msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.action.deleteFail"));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 162 */       e.printStackTrace();
/* 163 */       msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.exception"));
/*     */     }
/* 165 */     log.debug(msg);
/* 166 */     return msg;
/*     */   }

			@RequestMapping({"queryIndexInfo.do"})
			@ResponseBody
/*     */   public String queryIndexInfo() throws Exception {
/* 109 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/* 110 */    // String type = req.getParameter("type");
/* 111 */     String param_code = req.getParameter("param_code");
/* 112 */    List <TbBusinessConfigVo>  list = this.configLogic.queryConfigByInfo(param_code);
/* 113 */     //req.setAttribute("data", vo);
			String  str = GridJsonUtil.getDataGridJson(list.size(), list);
/* 114 */   /*  if ((!StringUtil.isEmpty(type)) && (type.equalsIgnoreCase("view"))) {
 115        return this.DETAIL_Config_INIT_JSP_PATH;
          }*/
/*     */     
/* 118 */     return str;
/*     */   }

 }

/* Location:           C:\maven\repo\com\hnbits\webcore\3.2.7-SNAPSHOT\webcore-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.app.system.action.ConfigAction
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */
