package com.hnbits.app.system.po;

/*    */ 
/*    */ import com.hnbits.app.PagerModel;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TbBusinessConfig
/*    */   extends PagerModel
/*    */ {
/*    */   private String param_code;
/*    */   private String param_name;
/*    */   private String param_val;
/*    */   private String param_type;
/*    */   private String param_scope;
/*    */   private String param_val_mode;
/*    */   private String param_val_type;
/*    */   private String create_user_id;
/*    */   private Date create_time;
/*    */   
/*    */   public TbBusinessConfig() {}
/*    */   
/*    */   public String getParam_val_mode()
/*    */   {
/* 30 */     return this.param_val_mode;
/*    */   }
/*    */   
/* 33 */   public void setParam_val_mode(String param_val_mode) { this.param_val_mode = param_val_mode; }
/*    */   
/*    */   public String getParam_val_type() {
/* 36 */     return this.param_val_type;
/*    */   }
/*    */   
/* 39 */   public void setParam_val_type(String param_val_type) { this.param_val_type = param_val_type; }
/*    */   
/*    */   public String getCreate_user_id() {
/* 42 */     return this.create_user_id;
/*    */   }
/*    */   
/* 45 */   public void setCreate_user_id(String create_user_id) { this.create_user_id = create_user_id; }
/*    */   
/*    */   public void setCreate_time(Date create_time) {
/* 48 */     this.create_time = create_time;
/*    */   }
/*    */   
/* 51 */   public String getParam_scope() { return this.param_scope; }
/*    */   
/*    */   public void setParam_scope(String param_scope) {
/* 54 */     this.param_scope = param_scope;
/*    */   }
/*    */   
/* 57 */   public String getParam_type() { return this.param_type; }
/*    */   
/*    */   public void setParam_type(String param_type) {
/* 60 */     this.param_type = param_type;
/*    */   }
/*    */   
/* 63 */   public String getParam_code() { return this.param_code; }
/*    */   
/*    */   public void setParam_code(String param_code) {
/* 66 */     this.param_code = param_code;
/*    */   }
/*    */   
/* 69 */   public String getParam_name() { return this.param_name; }
/*    */   
/*    */   public void setParam_name(String param_name) {
/* 72 */     this.param_name = param_name;
/*    */   }
/*    */   
/* 75 */   public String getParam_val() { return this.param_val; }
/*    */   
/*    */   public void setParam_val(String param_val) {
/* 78 */     this.param_val = param_val;
/*    */   }
/*    */   
/* 81 */   public Date getCreate_time() { return this.create_time; }
/*    */ }

/* Location:           C:\maven\repo\com\hnbits\webmodel\3.2.7-SNAPSHOT\webmodel-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.app.system.po.TbBusinessConfig
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */
