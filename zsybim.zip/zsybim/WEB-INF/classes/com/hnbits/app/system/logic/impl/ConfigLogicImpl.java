package com.hnbits.app.system.logic.impl;

/*     */ 
/*     */ import com.hnbits.app.system.dao.ConfigDao;
/*     */ import com.hnbits.app.system.logic.IConfigLogic;
/*     */ import com.hnbits.app.system.vo.TbBusinessConfigVo;
/*     */ import com.hnbits.util.StringUtil;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Service;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Service("configLogic")
/*     */ public class ConfigLogicImpl
/*     */   implements IConfigLogic
/*     */ {
/*  28 */   private static final Logger log = LoggerFactory.getLogger(ConfigLogicImpl.class);
/*     */   @Autowired
/*     */   private ConfigDao configDao;
/*     */   
/*     */   public ConfigLogicImpl() {}
/*     */   
/*  34 */   public TbBusinessConfigVo queryConfigById(String id) throws Exception { Map<String, Object> map = new HashMap();
/*  35 */     map.put("param_code", id);
/*  36 */     return this.configDao.queryConfigById(map);
/*     */   }
/*     */   
/*     */   public long queryConfig(TbBusinessConfigVo vo) throws Exception {
/*  40 */     Map<String, Object> map = new HashMap();
/*  41 */     String param_codeVal = vo.getParam_code();
/*  42 */     if (!StringUtil.isEmpty(param_codeVal))
/*  43 */       map.put("param_code", param_codeVal);
/*  44 */     String param_nameVal = vo.getParam_name();
/*  45 */     if (!StringUtil.isEmpty(param_nameVal))
/*  46 */       map.put("param_name", param_nameVal);
/*  47 */     String param_valVal = vo.getParam_val();
/*  48 */     if (!StringUtil.isEmpty(param_valVal))
/*  49 */       map.put("param_val", param_valVal);
/*  50 */     Date create_timeVal = vo.getCreate_time();
/*  51 */     if (!StringUtil.isEmpty(create_timeVal))
/*  52 */       map.put("create_time", create_timeVal);
/*  53 */     return this.configDao.queryConfig(map);
/*     */   }
/*     */   
/*     */   public List<TbBusinessConfigVo> queryConfigList(TbBusinessConfigVo vo, Integer currPage, Integer pageSize) throws Exception {
/*  57 */     Map<String, Object> map = new HashMap();
/*  58 */     if (vo != null) {
/*  59 */       String param_codeVal = vo.getParam_code();
/*  60 */       if (!StringUtil.isEmpty(param_codeVal))
/*  61 */         map.put("param_code", param_codeVal);
/*  62 */       String param_nameVal = vo.getParam_name();
/*  63 */       if (!StringUtil.isEmpty(param_nameVal))
/*  64 */         map.put("param_name", param_nameVal);
/*  65 */       String param_valVal = vo.getParam_val();
/*  66 */       if (!StringUtil.isEmpty(param_valVal))
/*  67 */         map.put("param_val", param_valVal);
/*  68 */       Date create_timeVal = vo.getCreate_time();
/*  69 */       if (!StringUtil.isEmpty(create_timeVal))
/*  70 */         map.put("create_time", create_timeVal);
/*     */     }
/*  72 */     if ((currPage != null) && (pageSize != null)) {
/*  73 */       map.put("pagestartno", Integer.valueOf((currPage.intValue() - 1) * pageSize.intValue()));
/*  74 */       map.put("pagesize", pageSize);
/*  75 */       map.put("pageendno", Integer.valueOf(currPage.intValue() * pageSize.intValue()));
/*     */     }
/*  77 */     return this.configDao.queryConfigList(map);
/*     */   }
/*     */   
/*     */   public int insertConfig(TbBusinessConfigVo vo) throws Exception {
/*  81 */     return this.configDao.insertConfig(vo);
/*     */   }
/*     */   
/*     */   public int deleteConfig(String id) throws Exception {
/*  85 */     String[] ids = id.split(",");
/*  86 */     Map<String, Object> map = new HashMap();
/*  87 */     map.put("ids", ids);
/*  88 */     return this.configDao.deleteConfig(map);
/*     */   }
/*     */   
/*     */   public int updateConfig(TbBusinessConfigVo vo) throws Exception {
/*  92 */     return this.configDao.updateConfig(vo);
/*     */   }
/*     */   
/*     */   public ConfigDao getConfigDao() {
/*  96 */     return this.configDao;
/*     */   }
/*     */   
/*     */   public void setConfigDao(ConfigDao dao) {
/* 100 */     this.configDao = dao;
/*     */   }
/*     */
			@Override
			public List<TbBusinessConfigVo> queryConfigByInfo(String id) throws Exception {
				Map<String, Object> map = new HashMap();
			    map.put("param_code", id);
		       return this.configDao.queryConfigByInfo(map);
		   }
}

/* Location:           C:\maven\repo\com\hnbits\webcore\3.2.7-SNAPSHOT\webcore-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.app.system.logic.impl.ConfigLogicImpl
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */
