package com.hnbits.app.system.dao;


import com.hnbits.app.system.vo.TbBusinessConfigVo;
import java.util.List;
import java.util.Map;

public abstract interface ConfigDao
{
  public abstract TbBusinessConfigVo queryConfigById(Map<String, Object> paramMap)
    throws Exception;
  
  public abstract long queryConfig(Map<String, Object> paramMap)
    throws Exception;
  
  public abstract List<TbBusinessConfigVo> queryConfigList(Map<String, Object> paramMap)
    throws Exception;
  
  public abstract int deleteConfig(Map<String, Object> paramMap)
    throws Exception;
  
  public abstract int updateConfig(TbBusinessConfigVo paramTbBusinessConfigVo)
    throws Exception;
  
  public abstract int insertConfig(TbBusinessConfigVo paramTbBusinessConfigVo)
    throws Exception;

  public abstract List<TbBusinessConfigVo> queryConfigByInfo(Map<String, Object> map)
	throws Exception;;
}

/* Location:           C:\maven\repo\com\hnbits\webcore\3.2.7-SNAPSHOT\webcore-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.app.system.dao.ConfigDao
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */
