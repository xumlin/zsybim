package com.hnbits.app.system.action;

/*     */ 
/*     */ import com.hnbits.app.BaseAction;
/*     */ import com.hnbits.app.system.logic.IConfigLogic;
/*     */ import com.hnbits.app.system.logic.IIndexLogic;
/*     */ import com.hnbits.app.system.logic.IMenuLogic;
/*     */ import com.hnbits.app.system.logic.IUserLogic;
/*     */ import com.hnbits.app.system.vo.TbBusinessConfigVo;
/*     */ import com.hnbits.app.system.vo.TbMenuButtonVo;
/*     */ import com.hnbits.app.system.vo.TbMenuVo;
/*     */ import com.hnbits.app.system.vo.TbUserVo;
/*     */ import com.hnbits.util.BeanUtil;
/*     */ import com.hnbits.util.PropertiesUtil;
/*     */ import com.hnbits.util.SessionUserUtil;
/*     */ import com.hnbits.util.SpringHttpUtil;
/*     */ import com.hnbits.util.StringUtil;
/*     */ import com.hnbits.util.easyui.Tree;
/*     */ import com.hnbits.util.ztree.ZTree;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Controller
/*     */ @RequestMapping({"admin/indexAction"})
/*     */ public class IndexAction
/*     */   extends BaseAction
/*     */ {
/*  42 */   private static final Logger log = LoggerFactory.getLogger(IndexAction.class);
/*     */   
/*     */ 
/*     */   @Autowired
/*     */   private IIndexLogic indexLogic;
/*     */   
/*     */   @Autowired
/*     */   private IUserLogic userLogic;
/*     */   
/*     */   @Autowired
/*     */   private IMenuLogic menuLogic;
/*     */   
/*     */   @Autowired
/*     */   private IConfigLogic configLogic;
/*     */   
/*  57 */   private final String LONGIN_INIT_JSP_PATH = "/jsp/index/login";
/*     */   
/*  59 */   private final String TIMEOUT_JSP_PATH = "/jsp/index/timeout";
/*     */   
/*     */   public IndexAction() {}
/*     */   
/*     */   @RequestMapping({"/login.do"})
/*  64 */   public String login() { log.info("开始登录!");
/*  65 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/*  66 */     String message = "";
/*  67 */     TbUserVo tblstaffVo = null;
/*  68 */     String userSso = "true";
/*     */     try {
/*  70 */       HttpSession session = SpringHttpUtil.getSession();
/*  71 */       String checkCode = req.getParameter("checkCode");
/*  72 */       String loginName = req.getParameter("loginName");
/*  73 */       String loginPwd = req.getParameter("loginPwd");
/*  74 */       String rightCheckCode = (String)req.getSession().getAttribute("checkCode");
/*  75 */       if ((loginName == null) || (loginPwd == null) || (checkCode == null)) {
/*  76 */         return "/jsp/index/login";
/*     */       }
/*  78 */       List<TbBusinessConfigVo> configList = this.configLogic.queryConfigList(null, null, null);
/*  79 */       Map<Object, TbBusinessConfigVo> configMap = null;
/*  80 */       if ((configList != null) && (configList.size() > 0)) {
/*  81 */         configMap = BeanUtil.list2Map(configList, "param_code");
/*     */       }
/*  83 */       if ((configMap != null) && (configMap.containsKey("system.user.sso"))) {
/*  84 */         userSso = ((TbBusinessConfigVo)configMap.get("system.user.sso")).getParam_val();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  90 */       tblstaffVo = this.indexLogic.txLogin(loginName, loginPwd);
/*     */       
/*  92 */       if (tblstaffVo == null) {
/*  93 */         message = "<font color='red'>用户账号不存在</font>";
/*     */ 
/*     */       }
/*  96 */       else if ((userSso.equalsIgnoreCase("true")) && (tblstaffVo.getLogin_status().equals("2"))) {
/*  97 */         message = "<font color='red'>用户已登录,不允许重复登录</font>";
/*     */ 
/*     */       }
/* 100 */       else if (tblstaffVo.getLogin_status().equals("0")) {
/* 101 */         message = "<font color='red'>用户密码错误</font>";
/*     */ 
/*     */       }
/* 104 */       else if (tblstaffVo.getLogin_status().equals("3")) {
/* 105 */         message = "<font color='red'>用户密码尝试超出次数限定</font>";
/*     */ 
/*     */       }
/* 108 */       else if (tblstaffVo.getLogin_status().equals("4")) {
/* 109 */         message = "<font color='red'>用户注销或锁定</font>";
/*     */       }
/*     */       else
/*     */       {
/* 113 */         tblstaffVo = this.userLogic.queryUserByID(tblstaffVo.getUser_id());
/* 114 */         session.setAttribute("SessionUserInfo", tblstaffVo);
/*     */       }
/*     */       
/*     */ 
/* 118 */       if ((message == null) || ("".equals(message))) {
/* 119 */         this.indexLogic.updateUserLoginStatus(tblstaffVo.getUser_id(), null, "1");
/*     */         
/* 121 */         return "redirect:/admin/indexAction/main.do";
/*     */       }
/* 123 */       req.setAttribute("message", message);
/* 124 */       log.info("结束登录,返回错误信息[" + message + "]");
/* 125 */       return "/jsp/index/login";
/*     */     }
/*     */     catch (Exception e) {
/* 128 */       log.error(e.getMessage(), e);
/* 129 */       req.setAttribute("message", e.getMessage());
/* 130 */       log.info("结束登录,返回错误信息[" + e.getMessage() + "]"); }
/* 131 */     return "/jsp/index/login";
/*     */   }
/*     */   
/*     */   @RequestMapping({"/main.do"})
/*     */   public String main(HttpServletRequest req, HttpServletResponse resp) throws Exception
/*     */   {
/* 137 */     TbUserVo userVo = SessionUserUtil.getUserFromSession();
/* 138 */     HttpSession session = req.getSession();
/* 139 */     String mainLayout = "left";
/* 140 */     String mainTheme = "default";
/* 141 */     if (userVo != null) {
/* 142 */       userVo = this.userLogic.queryUserByID(userVo.getUser_id());
/* 143 */       List<TbMenuButtonVo> menuButtonList = this.menuLogic.queryUserMenuButtonList(userVo.getUser_id());
/* 144 */       Map<String, String> map = new HashMap();
/* 145 */       if ((menuButtonList != null) && (menuButtonList.size() > 0)) {
/* 146 */         for (TbMenuButtonVo menuButtonVo : menuButtonList) {
/* 147 */           map.put(menuButtonVo.getBtn_code(), menuButtonVo.getBtn_name());
/*     */         }
/*     */       }
/* 150 */       userVo.setMenuButtonMap(map);
/* 151 */       session.setAttribute("SessionUserInfo", userVo);
/*     */       
/* 153 */       List<TbBusinessConfigVo> configList = this.configLogic.queryConfigList(null, null, null);
/* 154 */       Object configMap = null;
/* 155 */       if ((configList != null) && (configList.size() > 0)) {
/* 156 */         configMap = BeanUtil.list2Map(configList, "param_code");
/*     */       }
/*     */       
/* 159 */       List<TbMenuVo> listMenu = this.indexLogic.queryUserDirectSubMenu(userVo.getUser_id(), "0");
/* 160 */       session.setAttribute("listMenu", listMenu);
/*     */       
/* 162 */       List<TbMenuVo> listAllmenu = this.indexLogic.queryUserMenuList(userVo.getUser_id());
/* 163 */       Map<Object, List<TbMenuVo>> menuMap = BeanUtil.list2MapList(listAllmenu, "parent_menu_id");
/* 164 */       session.setAttribute("menuMap", menuMap);
/*     */       
/* 166 */       if ((configMap != null) && (((Map)configMap).containsKey("system.main.layout"))) {
/* 167 */         mainLayout = ((TbBusinessConfigVo)((Map)configMap).get("system.main.layout")).getParam_val();
/*     */       }
/*     */       else {
/* 170 */         configMap = new HashMap();
/* 171 */         TbBusinessConfigVo basicConfig = new TbBusinessConfigVo();
/* 172 */         basicConfig.setParam_code("system.main.layout");
/* 173 */         basicConfig.setParam_val(mainLayout);
/* 174 */         ((Map)configMap).put("system.main.layout", basicConfig);
/*     */       }
/*     */       
/* 177 */       if ((configMap != null) && (((Map)configMap).containsKey("system.main.theme"))) {
/* 178 */         mainTheme = ((TbBusinessConfigVo)((Map)configMap).get("system.main.theme")).getParam_val();
/*     */       }
/* 180 */       session.setAttribute("theme", StringUtil.isEmpty(userVo.getTheme()) ? mainTheme : userVo.getTheme());
/* 181 */       session.setAttribute("configMap", configMap);
/* 182 */       return "jsp/index/main";
/*     */     }
/* 184 */     return "redirect:login.do";
/*     */   }
/*     */   
/*     */   @ResponseBody
/*     */   @RequestMapping({"/loadallmenu.do"})
/*     */   public String loadallmenu() throws Exception
/*     */   {
/* 191 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/* 192 */     TbUserVo staffVo = SessionUserUtil.getUserFromSession();
/* 193 */     String msg = "";
/* 194 */     String type = req.getParameter("type");
/* 195 */     if (staffVo == null) {
/* 196 */       return msg;
/*     */     }
/*     */     try {
/* 199 */       List<TbMenuVo> menuList = this.indexLogic.queryUserMenuList(staffVo.getUser_id());
/* 200 */       List<String> attrList = new ArrayList();
/* 201 */       attrList.add("menu_url");
/* 202 */       attrList.add("menu_code");
/* 203 */       attrList.add("icon_name");
/* 204 */       attrList.add("menu_full_name");
/* 205 */       attrList.add("menu_open_method");
/* 206 */       attrList.add("menu_url_type");
/* 207 */       if ((StringUtil.isEmpty(type)) || (type.equals("easyui"))) {
/* 208 */         Tree tree = new Tree("menu_id", "parent_menu_id", "menu_name", null, null, "icon_name", attrList, menuList, new String[0]);
/* 209 */         msg = tree.buildJson(new String[0]);
/*     */       }
/*     */       else {
/* 212 */         ZTree tree = new ZTree("menu_id", "parent_menu_id", "menu_name", null, null, "icon_name", attrList, menuList, new String[0]);
/* 213 */         tree.setUrlField("menu_url");
/* 214 */         tree.setTarget("rightFrame");
/* 215 */         msg = tree.buildJson(new String[0]);
/*     */       }
/*     */     } catch (Exception e) {
/* 218 */       e.printStackTrace();
/*     */     }
/* 220 */     log.debug(msg);
/* 221 */     return msg;
/*     */   }
/*     */   
/*     */   @ResponseBody
/*     */   @RequestMapping({"/loadsubmenu.do"})
/*     */   public String loadsubmenu() throws Exception {
/* 227 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/* 228 */     TbUserVo staffVo = SessionUserUtil.getUserFromSession();
/* 229 */     String menuSuperID = req.getParameter("parent_menu_id");
/* 230 */     String msg = "";
/* 231 */     if (staffVo == null) {
/* 232 */       return msg;
/*     */     }
/*     */     try {
			List<TbMenuVo> menuList = new ArrayList();
			if(menuSuperID.equals("0")){
				 menuList = this.indexLogic.queryUserDirectSubMenu(staffVo.getUser_id(), menuSuperID);
			}else{
/* 235 */        menuList = this.indexLogic.queryUserSubMenu(staffVo.getUser_id(), menuSuperID);
			}
/* 236 */       List<String> attrList = new ArrayList();
/* 237 */       attrList.add("menu_url");
/* 238 */       attrList.add("menu_code");
/* 239 */       attrList.add("icon_name");
/* 240 */       attrList.add("menu_full_name");
/* 241 */       attrList.add("menu_open_method");
/* 242 */       attrList.add("menu_url_type");
/* 243 */       Tree tree = new Tree("menu_id", "parent_menu_id", "menu_name", null, null, "icon_name", attrList, menuList, new String[0]);
/* 244 */       msg = tree.buildJson(new String[0]);
/*     */     } catch (Exception e) {
/* 246 */       e.printStackTrace();
/*     */     }
/* 248 */     log.debug(msg);
/* 249 */     return msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @RequestMapping({"/logLogOut.do"})
/*     */   public String logLogOut()
/*     */     throws Exception
/*     */   {
/* 259 */     HttpSession session = SpringHttpUtil.getSession();
/* 260 */     TbUserVo tblstaffVo = (TbUserVo)session.getAttribute("SessionUserInfo");
/* 261 */     if (("true".equalsIgnoreCase(PropertiesUtil.getCommonConfig().getProperty("loginLog"))) && (tblstaffVo != null)) {
/* 262 */       this.indexLogic.txLogout(tblstaffVo.getUser_id(), tblstaffVo.getLast_login_id());
/*     */     }
/* 264 */     session.removeAttribute("SessionUserInfo");
/* 265 */     Enumeration allAttrs = session.getAttributeNames();
/* 266 */     while (allAttrs.hasMoreElements()) {
/* 267 */       String attrname = (String)allAttrs.nextElement();
/* 268 */       session.removeAttribute(attrname);
/*     */     }
/* 270 */     session.invalidate();
/* 271 */     return "/jsp/index/login";
/*     */   }
/*     */   
/*     */   @RequestMapping({"updateUnLogin.do"})
/*     */   public String updateUnLogin() throws Exception {
/* 276 */     HttpServletRequest req = SpringHttpUtil.getRequest();
/* 277 */     String userCode = req.getParameter("loginName");
/* 278 */     long rows = this.indexLogic.updateUserLoginStatus(null, userCode, "0");
/* 279 */     String msg = null;
/* 280 */     if (rows > 0L) {
/* 281 */       msg = "已重置用户状态为未登录!";
/*     */     }
/*     */     else {
/* 284 */       msg = "重置用户状态为未登录失败!";
/*     */     }
/* 286 */     req.setAttribute("message", msg);
/* 287 */     return "/jsp/index/login";
/*     */   }
/*     */   
/*     */   @RequestMapping({"checktimeout.do"})
/*     */   @ResponseBody
/*     */   public String checktimeout(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 293 */     HttpSession session = SpringHttpUtil.getSession();
/* 294 */     String msg = "";
/*     */     try {
/* 296 */       TbUserVo tblstaffVo = (TbUserVo)session.getAttribute("SessionUserInfo");
/* 297 */       if (tblstaffVo != null) {
/* 298 */         msg = "success";
/*     */       } else {
/* 300 */         msg = "timeout";
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 304 */       msg = "error";
/*     */     }
/* 306 */     return msg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @RequestMapping({"timeout.do"})
/*     */   public String timeout()
/*     */   {
/* 316 */     return "/jsp/index/timeout";
/*     */   }
/*     */   
/*     */   public IIndexLogic getIndexLogic() {
/* 320 */     return this.indexLogic;
/*     */   }
/*     */   
/*     */   public void setIndexLogic(IIndexLogic indexLogic) {
/* 324 */     this.indexLogic = indexLogic;
/*     */   }
/*     */ }

/* Location:           C:\maven\repo\com\hnbits\webcore\3.2.7-SNAPSHOT\webcore-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.app.system.action.IndexAction
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */