package com.hnbits.app.system.vo;

/*    */ 
/*    */ import com.hnbits.app.system.po.TbBusinessConfig;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TbBusinessConfigVo
/*    */   extends TbBusinessConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6913687071279686787L;
/*    */   private String param_type_desc;
/*    */   private String param_scope_desc;
/*    */   private String param_val_mode_desc;
/*    */   private String param_val_type_desc;
/*    */   
/*    */   public TbBusinessConfigVo() {}
/*    */   
/*    */   public String getParam_type_desc()
/*    */   {
/* 25 */     return this.param_type_desc;
/*    */   }
/*    */   
/*    */   public void setParam_type_desc(String param_type_desc) {
/* 29 */     this.param_type_desc = param_type_desc;
/*    */   }
/*    */   
/*    */   public String getParam_scope_desc() {
/* 33 */     return this.param_scope_desc;
/*    */   }
/*    */   
/*    */   public void setParam_scope_desc(String param_scope_desc) {
/* 37 */     this.param_scope_desc = param_scope_desc;
/*    */   }
/*    */   
/*    */   public String getParam_val_mode_desc() {
/* 41 */     return this.param_val_mode_desc;
/*    */   }
/*    */   
/*    */   public void setParam_val_mode_desc(String param_val_mode_desc) {
/* 45 */     this.param_val_mode_desc = param_val_mode_desc;
/*    */   }
/*    */   
/*    */   public String getParam_val_type_desc() {
/* 49 */     return this.param_val_type_desc;
/*    */   }
/*    */   
/*    */   public void setParam_val_type_desc(String param_val_type_desc) {
/* 53 */     this.param_val_type_desc = param_val_type_desc;
/*    */   }
/*    */ }

/* Location:           C:\maven\repo\com\hnbits\webmodel\3.2.7-SNAPSHOT\webmodel-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.app.system.vo.TbBusinessConfigVo
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */
