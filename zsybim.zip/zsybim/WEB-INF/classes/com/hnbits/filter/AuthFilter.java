/*    */ package com.hnbits.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class AuthFilter
/*    */   extends HttpServlet implements Filter
/*    */ {
/*    */   public AuthFilter() {}
/*    */   
/* 25 */   private final Logger log = LoggerFactory.getLogger(AuthFilter.class);
/*    */   
/*    */   private static final long serialVersionUID = 2463693429780241261L;
/*    */   
/* 29 */   private List<String> notCheckURLList = new ArrayList();
/*    */   
/*    */   public void destroy() {
/* 32 */     super.destroy();
/*    */   }
/*    */   
/*    */   public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
/* 36 */     HttpServletRequest req = (HttpServletRequest)servletRequest;
/* 37 */     HttpServletResponse res = (HttpServletResponse)servletResponse;

/* ----------------这里开始---------- */ 
			//HttpSession session = req.getSession();
			
			//已经登录，放行
	/*	if (session.getAttribute("is_login") != null) {
			chain.doFilter(req, res);
			return;
		}*/
		// 从认证中心回跳的带有token的请求，有效则放行
		/*String token = req.getParameter("token");
		if (token != null) {
			session.setAttribute("is_login", true);
			session.setAttribute("token", token);
			// 存储，用于注销
			//SessionStorage.INSTANCE.set(token, session);
			chain.doFilter(req, res);
			return;
		}*/

				// 重定向至登录页面，并附带当前请求地址
		     //res.sendRedirect("http://localhost:8080?client_url=" + req.getRequestURL());
/*    */     
/* 39 */     String contextPath = req.getContextPath();
/* 40 */     String uri = req.getRequestURI();
/* 41 */     this.notCheckURLList.add(contextPath + "/admin/indexAction/login.do");
/* 42 */     this.notCheckURLList.add(contextPath + "/page/jsp/index/login.jsp");
/* 43 */     this.notCheckURLList.add(contextPath + "/admin/indexAction/logLogOut.do");
/* 44 */     this.notCheckURLList.add(contextPath + "/page/jsp/index/main.jsp");
/* 45 */     this.notCheckURLList.add(contextPath + "/admin/indexAction/updateUnLogin.do");
/* 46 */     this.notCheckURLList.add(contextPath + "/modeler.html");
/* 47 */     this.notCheckURLList.add(contextPath + "/rest/");
/* 48 */     this.notCheckURLList.add(contextPath + "/service/");
/* 49 */     this.notCheckURLList.add(contextPath + "/editor-app/");
/* 50 */     this.notCheckURLList.add(contextPath + "/images/");
/* 51 */     this.notCheckURLList.add(contextPath + "/");
/* 52 */     if ((uri.endsWith(".jpg")) || (uri.endsWith(".gif")) || (uri.endsWith(".html")) || (uri.endsWith(".ico")) || (uri.endsWith(".png")) || (uri.endsWith(".js")) || (uri.endsWith(".css")) || 
/* 53 */       (uri.endsWith(".application")) || (uri.endsWith(".captcha"))) {
/* 54 */       chain.doFilter(servletRequest, servletResponse);
/* 55 */       return;
/*    */     }
/* 57 */     if (!this.notCheckURLList.contains(uri)) {
/* 58 */       if (req.getSession().getAttribute("SessionUserInfo") == null) {
/* 59 */         this.log.info("authorization failed : url session is not exists[" + uri + "]");
/* 60 */         if ((req.getHeader("x-requested-with") != null) && (req.getHeader("x-requested-with").equalsIgnoreCase("XMLHttpRequest"))) {
/* 61 */           PrintWriter printWriter = res.getWriter();
/* 62 */           printWriter.write("<script type='text/javascript'>window.top.location='" + contextPath + "/admin/indexAction/login.do" + "'</script>");
/* 63 */           printWriter.flush();
/* 64 */           printWriter.close();
/*    */         } else {
/* 66 */           res.sendRedirect(contextPath + "/admin/indexAction/login.do");
/*    */         }
/* 68 */         return;
/*    */       }
/* 70 */       chain.doFilter(servletRequest, servletResponse);
/*    */     } else {
/* 72 */       this.log.info("authorization success : url do not need validate [" + uri + "]");
/* 73 */       chain.doFilter(servletRequest, servletResponse);
/*    */     }
/*    */   }
/*    */   
/*    */   public void init(FilterConfig config) throws ServletException {
/* 78 */     super.init();
/*    */   }
/*    */ }

/* Location:           C:\maven\repo\com\hnbits\webcore\3.2.7-SNAPSHOT\webcore-3.2.7-SNAPSHOT.jar
 * Qualified Name:     com.hnbits.filter.AuthFilter
 * Java Class Version: 7 (51.0)
 * JD-Core Version:    0.7.0.1
 */