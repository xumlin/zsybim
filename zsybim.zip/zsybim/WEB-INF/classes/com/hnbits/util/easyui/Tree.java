/**
 * 
 */
package com.hnbits.util.easyui;

import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hnbits.common.tree.BaseTree;
import com.hnbits.util.ReflectionUtil;
import com.hnbits.util.StringUtil;



/**
 * 树形数据结构的实现，主要用于tree的数据构造
 * @author Xiaonian.Yang
 * 
 */
public class Tree<T> extends BaseTree<T>{
	
	public Tree(String idField, String parentField,List dataList,String ...defaultSetting){
		this.idField = idField;
		this.parentField = parentField;
		this.dataList = dataList;
		if(null != defaultSetting && defaultSetting.length > 0)
			this.defaultState = defaultSetting[0];
		initRoot();
		for(T treeNode:rootNodeList){
			tree.add(build(treeNode));
		}
	}
	
	public Tree(String idField, String parentField,String textField,List dataList,String ...defaultSetting){
		this.idField = idField;
		this.parentField = parentField;
		this.textField = textField;
		this.dataList = dataList;
		if(null != defaultSetting && defaultSetting.length > 0)
			this.defaultState = defaultSetting[0];
		initRoot();
		for(T treeNode:rootNodeList){
			tree.add(build(treeNode));
		}
	}
	
	/**
	 * 实例化Tree
	 * @param idField 匹配数据集中对应的id属性名称
	 * @param parentField 匹配数据集中对应的parentId属性名称
	 * @param textField 匹配数据集中对应的text属性名称
	 * @param checkedField 匹配数据集中对应的checked属性名称
	 * @param stateField 匹配数据集中对应的state属性名称
	 * @param dataList 数据集
	 */
	public Tree(String idField, String parentField, String textField, String checkedField,String stateField,List dataList,String ...defaultSetting) {
		super();
		this.idField = idField;
		this.parentField = parentField;
		this.textField = textField;
		this.checkedField = checkedField;
		this.stateField = stateField;
		this.dataList = dataList;
		if(null != defaultSetting && defaultSetting.length > 0)
			this.defaultState = defaultSetting[0];
	}
	
	public Tree(String idField, String parentField, String textField, String checkedField,String stateField,List attrList,List dataList,String ...defaultSetting) {
		super();
		this.idField = idField;
		this.parentField = parentField;
		this.textField = textField;
		this.checkedField = checkedField;
		this.stateField = stateField;
		this.attributesList = attrList;
		this.dataList = dataList;
		if(null != defaultSetting && defaultSetting.length > 0)
			this.defaultState = defaultSetting[0];
	}
	
	public Tree(String idField, String parentField, String textField, String checkedField,String stateField,String iconField,List attrList,List dataList,String ...defaultSetting) {
		super();
		this.idField = idField;
		this.parentField = parentField;
		this.textField = textField;
		this.checkedField = checkedField;
		this.stateField = stateField;
		this.iconField = iconField;
		this.attributesList = attrList;
		this.dataList = dataList;
		if(null != defaultSetting && defaultSetting.length > 0)
			this.defaultState = defaultSetting[0];
	}
	
	/**
	 * 将普通数据记录集构建成TreeNode数据结构，记录集中需要有明确的父子结构描述，
	 * 可以通过指定idField，parentField，textField，checkedField，stateField 来匹配
	 * 数据记录集中的数据
	 * @param treeNode
	 */
	protected JSONObject build(T treeNode){
		JSONObject obj = new JSONObject();
		obj.put("id", ReflectionUtil.getFieldValue(treeNode, this.idField).toString().trim());
		if(null != this.parentField)
			obj.put("parentid", ReflectionUtil.getFieldValue(treeNode, this.parentField));
		if(null != this.textField)
			obj.put("text", ReflectionUtil.getFieldValue(treeNode, this.textField));
		if(null != this.checkedField){
			Object checked = ReflectionUtil.getFieldValue(treeNode, this.checkedField);
			obj.put("checked", StringUtil.isEmpty(checked) ? checked : Boolean.valueOf(checked.toString()));
		}
		if(null != this.stateField)
			obj.put("state", ReflectionUtil.getFieldValue(treeNode, this.stateField));
		if(null != this.iconField)
			obj.put("iconCls", ReflectionUtil.getFieldValue(treeNode, this.iconField));
		Boolean isleaf = false;
		if(hasChild(treeNode)){
			List<T> children = getChildren(treeNode);
			if(null != children && children.size() > 0){
				JSONArray childrenArray = new JSONArray();
				for(T o:children){
					JSONObject childrenObj = build(o);
					childrenArray.add(childrenObj);
				}
				obj.put("children", childrenArray);
				if(null != defaultState)
					obj.put("state",defaultState);
				else if(null != this.stateField){
					obj.put("state",ReflectionUtil.getFieldValue(treeNode, this.stateField));
				}
				else{
					obj.put("state","closed");
				}
			}
		}
		else{
			isleaf = true;
		}
		JSONObject attrObj = new JSONObject();
		attrObj.put("isleaf", isleaf);
		if(null != this.attributesList && this.attributesList.size() > 0){
			for(int i = 0 ; i < this.attributesList.size(); i++){
				String attr = this.attributesList.get(i);
				Object attrVal = ReflectionUtil.getFieldValue(treeNode, attr);
				attrObj.put(attr, attrVal);
			}
		}
		obj.put("attributes", attrObj);
		return obj;
	}
	
}
