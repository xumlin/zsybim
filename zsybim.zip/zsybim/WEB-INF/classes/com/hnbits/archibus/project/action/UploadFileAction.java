package com.hnbits.archibus.project.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hnbits.archibus.project.vo.ProjectVo;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;

/**
 * 
 * <br>
 * <b>功能：</b>ProjectEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Controller
@RequestMapping("upload/uploadFileAction")
public class UploadFileAction extends BossBaseAction<ProjectVo> {

	private final static Logger log = LoggerFactory.getLogger(UploadFileAction.class);

	@RequestMapping("upload.do")
	@ResponseBody
	public String queryAll(HttpServletRequest request, HttpServletResponse response) throws Exception {
		 String pname = request.getParameter("pname");

		// 得到上传文件的保存目录，将上传的文件存放于WEB-INF目录下，不允许外界直接访问，保证上传文件的安全
		String savePath = request.getServletContext().getRealPath("/WEB-INF/upload/")+pname;
		System.out.println(savePath);
		File file = new File(savePath);
		// 判断上传文件的保存目录是否存在
		if (!file.exists() && !file.isDirectory()) {
			System.out.println(savePath + "目录不存在，需要创建");
			// 创建目录
			//java.io.File.mkdir()：只能创建一级目录，且父目录必须存在，否则无法成功创建一个目录。
			//java.io.File.mkdirs()：可以创建多级目录，父目录不一定存在。
			file.mkdirs();
		}
		// 消息提示
		String message = "";
		String name = "";
		String value = "";
		try {
			// 使用Apache文件上传组件处理文件上传步骤：
			// 1、创建一个DiskFileItemFactory工厂
			DiskFileItemFactory factory = new DiskFileItemFactory();
			// 2、创建一个文件上传解析器
			ServletFileUpload upload = new ServletFileUpload(factory);
			// 解决上传文件名的中文乱码
			upload.setHeaderEncoding("UTF-8");
			// 3、判断提交上来的数据是否是上传表单的数据
			if (!ServletFileUpload.isMultipartContent(request)) {
				// 按照传统方式获取数据
				return "";
			}
			// 4、使用ServletFileUpload解析器解析上传数据，解析结果返回的是一个List<FileItem>集合，每一个FileItem对应一个Form表单的输入项
			List<FileItem> list = upload.parseRequest(request);

			for (FileItem item : list) {
				// 如果fileitem中封装的是普通输入项的数据
				if (item.isFormField()) {
					name = item.getFieldName();
					// 解决普通输入项的数据的中文乱码问题
					value = item.getString("UTF-8");
					// value = new
					// String(value.getBytes("iso8859-1"),"UTF-8");输出用户名
					System.out.println(name + "=" + value);
				} else {// 如果fileitem中封装的是上传文件
						// 得到上传的文件名称，
					String filename = item.getName();
					if (filename == null || filename.trim().equals("")) {
						continue;
					}
					// 注意：不同的浏览器提交的文件名是不一样的，有些浏览器提交上来的文件名是带有路径的，如：
					// c:\a\b\1.txt，而有些只是单纯的文件名，如：1.txt
					// 处理获取到的上传文件的文件名的路径部分，只保留文件名部分
					filename = filename.substring(filename.lastIndexOf("\\") + 1);
					// 获取item中的上传文件的输入流
					InputStream in = item.getInputStream();
					// 创建一个文件输出流
					FileOutputStream out = new FileOutputStream(savePath + "\\" + filename);
					// 创建一个缓冲区
					byte buffer[] = new byte[1024];
					// 判断输入流中的数据是否已经读完的标识
					int len = 0;
					// 循环将输入流读入到缓冲区当中，(len=in.read(buffer))>0就表示in里面还有数据
					while ((len = in.read(buffer)) > 0) {
						// 使用FileOutputStream输出流将缓冲区的数据写入到指定的目录(savePath + "\\"
						// + filename)当中
						out.write(buffer, 0, len);
					}
					// 关闭输入流
					in.close();
					// 关闭输出流
					out.close();
					// 删除处理文件上传时生成的临时文件
					item.delete();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{\"data\":\"success\"}";
	}

	@RequestMapping("downloadFile.do")
	public void downloadFile(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String path = request.getParameter("path");
		File file = new File(path);
		if(file.isDirectory()){
			//文件夹
			return;
		}else if(!file.exists()){
			//文件不存在
			return;
		} else if(file.isFile()){
			//文件
			String filename = file.getName();
			//设置响应头，控制浏览器下载该文件
		       response.setHeader("content-disposition", "attachment;filename=" + URLEncoder.encode(filename, "UTF-8"));
		       //读取要下载的文件，保存到文件输入流
		       FileInputStream in = new FileInputStream(file);
		       //创建输出流
		       OutputStream out = response.getOutputStream();
		       //创建缓冲区
		       byte buffer[] = new byte[1024];
		       int len = 0;
		       //循环将输入流中的内容读取到缓冲区当中
		       while((len=in.read(buffer))>0){
		           //输出缓冲区的内容到浏览器，实现文件下载
		           out.write(buffer, 0, len);
		       }
		       //关闭文件输入流
		       in.close();
		       //关闭输出流
		       out.close();
		}
	}
	
	@RequestMapping(value = "fileList.do", method = RequestMethod.GET)
	@ResponseBody
	public Object listFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
	     String pname = request.getParameter("pname");
		String path = request.getServletContext().getRealPath("/WEB-INF/upload/")+pname;
		/*
		 [
		    {
		        "name": "file1.txt",
		        "type": "0"
		    },
		    {
		        "name": "folder1",
		        "type": "1",
		        "sub": [
		            {
		                "name": "file2.txt",
		                "type": "0"
		            },
		            {
		                "name": "folder1",
		                "type": "1",
		                "sub": [
		                    {
		                        "name": "file3.txt",
		                        "type": "0"
		                    },
		                    {
		                        "name": "file4.txt",
		                        "type": "0"
		                    }
		                ]
		            }
		        ]
		    }
		]
		 */
		File file = new File(path);
		File[] tempList = file.listFiles();
		List<Map<String, Object>> data = new ArrayList<>();
		if(tempList == null){
			return null;
		}else{
			for (int i = 0; i < tempList.length; i++) {
				if (tempList[i].isFile()) {
					Map<String,Object> f = new HashMap<>();
					f.put("name", tempList[i].getName());
					f.put("path", tempList[i].getPath());
					f.put("pname", pname);
					data.add(f);
				}
				/*if (tempList[i].isDirectory()) {
					Map<String,Object> f = new HashMap<>();
					f.put("name", tempList[i].getName());
					f.put("path", tempList[i].getPath());
					f.put("type", "1");
					f.put("sub", new ArrayList<>());
					data.add(f);
				}*/
			}
		}
		return data;
	}
	
	/**
	 * 删除文件
	 * @param path
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "deleteFile.do", method = RequestMethod.POST)
	@ResponseBody
	public String deleteFile(HttpServletRequest request) throws Exception{
		String result = "";
		String path = request.getParameter("path");
		File file = new File(path);
		if(file != null){
			file.delete();
			result = "success";
		}else{
			result = "error";
		}
		return result;
	}
	
	/**
	 * 文件重命名
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "modifyFileName.do", method = RequestMethod.POST)
	@ResponseBody
	public String deletmodifyFileNameeFile(HttpServletRequest request) throws Exception{
		String result = "";
		String path = request.getParameter("path");
		String newFileName = request.getParameter("newFileName");
		String pname = request.getParameter("pname");
		result = this.renameFile(request, path, newFileName,pname);
		return result;
	}
	
   /**文件重命名 
    * @param oldname  原来的文件名 
    * @param newname 新文件名 
    */ 
    public String renameFile(HttpServletRequest request, String oldname,String newname,String pname){
    	String result = "";
    	String path = request.getServletContext().getRealPath("/WEB-INF/upload/")+pname;
        if(!oldname.equals(newname)){//新的文件名和以前文件名不同时,才有必要进行重命名 
            File oldfile=new File(oldname); 
            File newfile=new File(path+"/"+newname); 
            if(!oldfile.exists()){
            	result = "重命名文件不存在";//重命名文件不存在
            }
            if(newfile.exists()){//若在该目录下已经有一个文件和新文件名相同，则不允许重命名 
                System.out.println(newname+"已经存在！"); 
                result = newname+"已经存在！";
            }else{ 
                oldfile.renameTo(newfile); 
            } 
        }else{
            System.out.println("新文件名和旧文件名相同...");
            result = "新文件名和旧文件名相同...";
        }
        return result;
    }

	public List<File> getFileList(String strPath) {
		List<File> filelist = new ArrayList<>();
		File dir = new File(strPath);
		File[] files = dir.listFiles(); // 该文件目录下文件全部放入数组
		if (files != null) {
			for (int i = 0; i < files.length; i++) {
				String fileName = files[i].getName();
				if (files[i].isDirectory()) { // 判断是文件还是文件夹
					getFileList(files[i].getAbsolutePath()); // 获取文件绝对路径
				} else if (fileName.endsWith("avi")) { // 判断文件名是否以.avi结尾
					String strFileName = files[i].getAbsolutePath();
					System.out.println("---" + strFileName);
					filelist.add(files[i]);
				} else {
					continue;
				}
			}

		}
		return filelist;
	}

	public void listfile(File file, Map<String, String> map) {
		// 如果file代表的不是一个文件，而是一个目录
		if (!file.isFile()) {
			// 列出该目录下的所有文件和目录
			File files[] = file.listFiles();
			// 遍历files[]数组
			for (File f : files) {
				// 递归
				listfile(f, map);
			}
		} else {

			String realName = file.getName().substring(file.getName().indexOf("_") + 1);
			// file.getName()得到的是文件的原始名称，这个名称是唯一的，因此可以作为key，realName是处理过后的名称，有可能会重复
			map.put(file.getName(), realName);
		}
	}

	@Override
	protected void ddlAfter(ProjectVo arg0) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public BaseLogic<ProjectVo> getLogic() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void queryListAfter(List<ProjectVo> arg0) throws Exception {
		// TODO Auto-generated method stub

	}

}
