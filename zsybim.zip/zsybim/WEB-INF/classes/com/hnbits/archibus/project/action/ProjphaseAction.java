package com.hnbits.archibus.project.action;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.hnbits.util.StringUtil;
import com.hnbits.app.BaseAction;
import com.hnbits.util.MsgUtil;
import com.hnbits.util.SpringHttpUtil;
import com.hnbits.util.easyui.GridJsonUtil;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;

import com.hnbits.archibus.project.vo.ProjphaseVo;
import com.hnbits.archibus.project.logic.impl.ProjphaseLogicImpl;

/**
 * 
 * <br>
 * <b>功能：</b>ProjphaseEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Controller
@RequestMapping("project/projphaseAction") 
public class ProjphaseAction extends BossBaseAction<ProjphaseVo>{
	
	private final static Logger log= LoggerFactory.getLogger(ProjphaseAction.class);
	
	@Resource(name="projphaseLogic")
	private ProjphaseLogicImpl projphaseLogic; 
	
	
	private static final String page_toList = "jsp/archibus/project/projphaseList";
	private static final String page_toAdd = "jsp/archibus/project/projphaseAdd";
	private static final String page_toEdit = "jsp/archibus/project/projphaseEdit";
	
	public ProjphaseAction() {
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}
	
	@Override
	public BaseLogic<ProjphaseVo> getLogic() {
		// TODO Auto-generated method stub
		return projphaseLogic;
	}

	@Override
	protected void queryListAfter(List<ProjphaseVo> e) throws Exception {
		
	}

	@Override
	protected void ddlAfter(ProjphaseVo vo) throws Exception {
		
	}
}
