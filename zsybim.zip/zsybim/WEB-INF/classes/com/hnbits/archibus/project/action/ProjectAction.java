package com.hnbits.archibus.project.action;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hnbits.app.PagerModel;
import com.hnbits.archibus.project.logic.impl.ProjectLogicImpl;
import com.hnbits.archibus.project.vo.ProjectVo;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;

/**
 * 
 * <br>
 * <b>功能：</b>ProjectEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Controller
@RequestMapping("project/projectAction") 
public class ProjectAction extends BossBaseAction<ProjectVo>{
	
	private final static Logger log= LoggerFactory.getLogger(ProjectAction.class);
	
	@Resource(name="projectLogic")
	private ProjectLogicImpl projectLogic; 
	
	
	private static final String page_toList = "jsp/archibus/project/projectList";
	private static final String page_toAdd = "jsp/archibus/project/projectAdd";
	private static final String page_toEdit = "jsp/archibus/project/projectEdit";
	
	public ProjectAction() {
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}
	
	@Override
	public BaseLogic<ProjectVo> getLogic() {
		// TODO Auto-generated method stub
		return projectLogic;
	}
	
	@RequestMapping("queryPage.do")
	public String queryAll(HttpServletRequest request,@ModelAttribute("params") ProjectVo vo) throws Exception{
		log.info("开始查询!");
		String str = null;
		List<ProjectVo> list = null;
		try{
			PagerModel pager = this.getLogic().queryPageList(vo);
			request.setAttribute("pager", pager);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		log.debug(str);
		log.info("结束查询系统参数配置,返回记录数["+ ((null == list) ? "null" : list.size())  +"]!");
		return "jsp/archibus/project/projectPage";
	}

	@Override
	protected void queryListAfter(List<ProjectVo> e) throws Exception {
		
	}

	@Override
	protected void ddlAfter(ProjectVo vo) throws Exception {
		
	}
}
