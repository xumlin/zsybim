package com.hnbits.archibus.project.vo;

import com.hnbits.archibus.project.po.Project;

/**
 * 
 * <br>
 * <b>功能：</b>ProjectVo<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
public class ProjectVo extends Project{
		//名,姓	private String name_last;	//名,姓	private String name_first;	//项目类型,项目类型描述	private String project_type_ch;	//项目类型,项目类型描述	private String project_type_description_ch;	//项目阶段名称	private String proj_phase_ch;		public String getName_last() {	    return this.name_last;	}	public void setName_last(String name_last) {	    this.name_last=name_last;	}	public String getName_first() {	    return this.name_first;	}	public void setName_first(String name_first) {	    this.name_first=name_first;	}	public String getProject_type_ch() {	    return this.project_type_ch;	}	public void setProject_type_ch(String project_type_ch) {	    this.project_type_ch=project_type_ch;	}	public String getProject_type_description_ch() {	    return this.project_type_description_ch;	}	public void setProject_type_description_ch(String project_type_description_ch) {	    this.project_type_description_ch=project_type_description_ch;	}	public String getProj_phase_ch() {	    return this.proj_phase_ch;	}	public void setProj_phase_ch(String proj_phase_ch) {	    this.proj_phase_ch=proj_phase_ch;	}
}
