package com.hnbits.archibus.project.logic.impl;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.hnbits.archibus.project.dao.ProjectDao;
import com.hnbits.archibus.project.vo.ProjectVo;
import com.hnbits.common.logic.impl.BaseLogicImpl;


/**
 * 
 * <br>
 * <b>功能：</b>ProjectEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Service("projectLogic")
public class ProjectLogicImpl extends BaseLogicImpl<ProjectVo, ProjectDao>{
	private final static Logger log= Logger.getLogger(ProjectLogicImpl.class);
	
	
	@Resource(name = "projectDao")
	@Override
	public void setBaseDao(ProjectDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}

}
