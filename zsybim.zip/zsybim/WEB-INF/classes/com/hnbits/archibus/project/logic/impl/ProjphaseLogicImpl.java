package com.hnbits.archibus.project.logic.impl;

import javax.annotation.Resource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hnbits.common.logic.impl.BaseLogicImpl;
import com.hnbits.util.StringUtil;
import com.hnbits.archibus.project.vo.ProjphaseVo;
import com.hnbits.archibus.project.dao.ProjphaseDao;


/**
 * 
 * <br>
 * <b>功能：</b>ProjphaseEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Service("projphaseLogic")
public class ProjphaseLogicImpl extends BaseLogicImpl<ProjphaseVo, ProjphaseDao>{
	private final static Logger log= Logger.getLogger(ProjphaseLogicImpl.class);
	
	
	@Resource(name = "projphaseDao")
	@Override
	public void setBaseDao(ProjphaseDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}

}
