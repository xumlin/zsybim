package com.hnbits.archibus.base.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.hnbits.app.system.vo.TbDeptVo;
import com.hnbits.app.system.vo.TbUserVo;
import com.hnbits.archibus.base.logic.impl.EqLogicImpl;
import com.hnbits.archibus.base.vo.EqVo;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;
import com.hnbits.util.SessionUserUtil;
import com.hnbits.util.SpringHttpUtil;
import com.hnbits.util.StringUtil;
import com.hnbits.util.easyui.Tree;

/**
 * 
 * <br>
 * <b>功能：</b>EqEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Controller
@RequestMapping("base/eqAction") 
public class EqAction extends BossBaseAction<EqVo>{
	
	private final static Logger log= LoggerFactory.getLogger(EqAction.class);
	
	@Resource(name="eqLogic")
	private EqLogicImpl eqLogic; 
	
	
	private static final String page_toList = "jsp/archibus/base/eqList";
	private static final String page_toAdd = "jsp/archibus/base/eqAdd";
	private static final String page_toEdit = "jsp/archibus/base/eqEdit";
	
	public EqAction() {
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}
	
	@Override
	public BaseLogic<EqVo> getLogic() {
		// TODO Auto-generated method stub
		return eqLogic;
	}
	
	@RequestMapping("queryEqTree.do")
	@ResponseBody
	public String loadUserDeptAllTree() {
		log.info("开始查询检查点信息树!");
		String str = null;
		List<EqVo> list = null;
		try {
			HttpServletRequest req = SpringHttpUtil.getRequest();
			String rootDeptId = "0";
			EqVo vo = (EqVo)SpringHttpUtil.getParameterVo(req, EqVo.class, true);
			list = this.eqLogic.queryEqTree(vo);
			List<String> attrList = new ArrayList<String>();
			attrList.add("parent_id");
			attrList.add("level");
			attrList.add("bl_id");
			attrList.add("fl_id");
			attrList.add("rm_id");
			attrList.add("dwgname");
			attrList.add("rm_type");
			attrList.add("rm_cat");
			Tree deptTree = new Tree("id", "parent_id", "name", "checked", "state", attrList, list);
			str = deptTree.buildJson(rootDeptId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.debug("tree:" + str);
		log.info("结束查询检修点信息树,返回记录数[" + ((null == list) ? "null" : list.size()) + "]!");
		return str;
	}
	
	@RequestMapping("queryEqStat.do")
	@ResponseBody
	public String queryEqFlStat() throws Exception{
		List<Map> list = null;
		HttpServletRequest req = SpringHttpUtil.getRequest();
		String type = req.getParameter("type");
		EqVo vo = new EqVo();
		if(!StringUtil.isEmpty(type) && type.equals("1")){
			list = this.eqLogic.queryEqFlStat(vo);
		}
		return JSONArray.toJSONString(list);
	}

	@Override
	protected void queryListAfter(List<EqVo> e) throws Exception {
		
	}

	@Override
	protected void ddlAfter(EqVo vo) throws Exception {
		
	}
}
