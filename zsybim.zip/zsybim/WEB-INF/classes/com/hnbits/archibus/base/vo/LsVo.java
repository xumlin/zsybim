package com.hnbits.archibus.base.vo;

import com.hnbits.archibus.base.po.Ls;

public class LsVo extends Ls {

	private static final long serialVersionUID = 66839478825852343L;

}
