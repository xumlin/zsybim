package com.hnbits.archibus.base.action;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author menglin.xu
 * @createDate 2018年9月25日
 * @file WeekDayUtil.java
 * @package com.hnbits.archibus.base.action
 * @project zsybim
 * @version 1.0
 */
public class WeekDayUtil {
	public static void main(String[] args) {
		// getDate0("2018-09-26 00:00:00.0","18");
		// getDate1("2018-09-25","星期一");
		// getDate2("2018-09-01","26");
		 getDate3("2018-09-27","1,星期二");
		 //getDate4("2018-09-01","2,星期二");
	}

	/**
	 * 固定周期天
	 * 
	 * @param dateFrom
	 * @param ruleNum
	 * @return
	 */
	public static String getDate0(String dateFrom, String ruleNum) {
		String time = "";
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dtime = sdf.format(new Date());
		if ((dtime.compareTo(dateFrom) >= 0)) {
			try {
				calendar.setTime(sdf.parse(dtime));
				calendar.add(Calendar.DATE, Integer.parseInt(ruleNum));
				time = calendar.get(Calendar.YEAR) + "-" + (calendar.get(Calendar.MONTH) + 1) + "-"
						+ calendar.get(Calendar.DATE) + " " + calendar.get(Calendar.HOUR_OF_DAY) + ":"
						+ calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return time;
	}

	/**
	 * 每周 获取某一时间段特定星期几的日期
	 * 
	 * @param dateFrom
	 *            开始时间
	 * @param dateEnd
	 *            结束时间
	 * @param weekDays
	 *            星期
	 * @return 返回时间数组
	 */
	public static String getDate1(String dateFrom, String weekDays) {
		long time = 1l;
		long perDayMilSec = 24 * 60 * 60 * 1000;
		List<String> dateList = new ArrayList<String>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dtime = sdf.format(new Date());
		// 需要查询的星期系数
		String strWeekNumber = weekForNum(weekDays);
		try {
			dtime = sdf.format(sdf.parse(dtime).getTime() - perDayMilSec);
			for (int i = 1; i < 8; i++) {
				time = sdf.parse(dtime).getTime();
				time = time + perDayMilSec;
				Date date = new Date(time);
				dtime = sdf.format(date);
				if (dateFrom.compareTo(dtime) <= 0) {
					// 查询的某一时间的星期系数
					Integer weekDay = dayForWeek(date);
					// 判断当期日期的星期系数是否是需要查询的
					if (strWeekNumber.indexOf(weekDay.toString()) != -1) {
						System.out.println(dtime);
						dateList.add(dtime);
					}
				} else {
					break;
				}
			}
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		String[] dateArray = new String[dateList.size()];
		dateList.toArray(dateArray);
		return dateArray[0];
	}

	/**
	 * 每月
	 * 
	 * @param dateFrom
	 * @param ruleNum
	 * @return
	 */
	public static String getDate2(String dateFrom, String ruleNum) {
		String time = "";
		Calendar calendar = Calendar.getInstance();
		int ri = calendar.get(Calendar.DAY_OF_MONTH);// 当前
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dtime = sdf.format(new Date());
		time = dtime.substring(0, dtime.length() - 2) + ruleNum;
		try {
			if ((dtime.compareTo(dateFrom) >= 0)) {// 当前时间大于执行时间
				if (ri > Integer.parseInt(ruleNum)) {
					calendar.setTime(sdf.parse(time));// 设置日历时间
					calendar.add(Calendar.MONTH, 1);// 在日历的月份上增加1个月
					time = sdf.format(calendar.getTime());// 的到你想要得6个月后的日期

				} else {
					time = sdf.format(sdf.parse(dtime.substring(0, dateFrom.length() - 2) + ruleNum));
				}
			}

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return time;
	}

	/**
	 * 每季
	 * 
	 * @param dateFrom
	 * @param ruleNum
	 * @return
	 */
	public static String getDate3(String dateFrom, String ruleNum) {
		int temp;
		String dtime = "";
		String[] rule = ruleNum.split(",");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dtime0 = sdf.format(new Date());
		if ((dtime0.compareTo(dateFrom) >= 0)) {
			Calendar calendar = Calendar.getInstance();
			int dmonth = calendar.get(Calendar.MONTH) + 1;
			int year = calendar.get(Calendar.YEAR);
			if (dmonth >= 3 && dmonth < 6) {
				temp = 3;
			} else if (dmonth >= 6 && dmonth < 9) {
				temp = 6;
			} else if (dmonth >= 9 && dmonth < 12) {
				temp = 9;
			} else {
				temp = 12;
			}
			String mon = "";
			if (temp != 12) {
				mon = temp + Integer.parseInt(rule[0])-1 + "";
			} else {
				switch (rule[0]) {
				case "1":
					mon = "12";
					break;
				case "2":
					mon = "1";
					year += 1;
					break;
				case "3":
					mon = "2";
					year += 1;
					break;
				default:
					break;
				}
			}
			dtime = year + "-" + mon + "-1"+" 00:00:00";
			dtime = getValue(dtime, rule[1]);
		}
		return dtime;
	}

	/**
	 * 每年
	 * 
	 * @param dateFrom
	 * @param ruleNum
	 * @return
	 */
	public static String getDate4(String dateFrom, String ruleNum) {
		String dtime = "";
		String[] rule = ruleNum.split(",");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dtime0 = sdf.format(new Date());
		if ((dtime0.compareTo(dateFrom) >= 0)) {
			Calendar calendar = Calendar.getInstance();
			int mon = Integer.parseInt(rule[0]);
			int dyear = calendar.get(Calendar.YEAR);
			int dmonth = calendar.get(Calendar.MONTH);
			if (dmonth >= mon) {// 时间已过
				dtime = dyear + 1 + "-" + mon + "-1 00:00:00";
			} else {
				dtime = dyear + "-" + mon + "-1 00:00:00";
			}
			dtime = getValue(dtime, rule[1]);
		}
		return dtime;
	}

	public static String getValue(String dtime, String str) {
		long time = 1l;
		long perDayMilSec = 24 * 60 * 60 * 1000;
		String strWeekNumber = weekForNum(str);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			dtime = sdf.format(sdf.parse(dtime).getTime() - perDayMilSec);
			for (int i = 1; i < 8; i++) {
				time = sdf.parse(dtime).getTime();
				time = time + perDayMilSec;
				Date date = new Date(time);
				dtime = sdf.format(date);
				Integer weekDay = dayForWeek(date);
				if (strWeekNumber.indexOf(weekDay.toString()) != -1) {
					System.out.println(dtime);
					return dtime;
				}
			}
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		return null;
	}

	
	
	static Timestamp getTime(String dateFrom, String ruleUnit, String ruleNum) {
		String time = "";
		if ("天".equals(ruleUnit)) {
			time = WeekDayUtil.getDate0(dateFrom, ruleNum);
		} else if ("每周".equals(ruleUnit)) {
			time = WeekDayUtil.getDate1(dateFrom, ruleNum);
		} else if ("每月".equals(ruleUnit)) {
			time = WeekDayUtil.getDate2(dateFrom, ruleNum);
		} else if ("每季".equals(ruleUnit)) {
			time = WeekDayUtil.getDate3(dateFrom, ruleNum);
		} else if ("每年".equals(ruleUnit)) {
			time = WeekDayUtil.getDate4(dateFrom, ruleNum);
		}

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date utilDate = null;
		try {
			utilDate = df.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		time = df.format(utilDate);
		Timestamp ts = Timestamp.valueOf(time);
		return ts;
	}
	
	// 等到当期时间的周系数。星期日：1，星期一：2，星期二：3，星期三：4，星期四：5，星期五：6，星期六：7
	public static Integer dayForWeek(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.DAY_OF_WEEK);
	}

	/**
	 * 得到对应星期的系数 星期日：1，星期一：2，星期二：3，星期三：4，星期四：5，星期五：6，星期六：7
	 * 
	 * @param weekDays
	 *            星期格式 星期一|星期二
	 */
	public static String weekForNum(String weekDays) {
		// 返回结果为组合的星期系数
		String weekNumber = "";
		// 解析传入的星期
		if (weekDays.indexOf("|") != -1) {// 多个星期数
			String[] strWeeks = weekDays.split("\\|");
			for (int i = 0; i < strWeeks.length; i++) {
				weekNumber = weekNumber + "" + getWeekNum(strWeeks[i]).toString();
			}
		} else {// 一个星期数
			weekNumber = getWeekNum(weekDays).toString();
		}

		return weekNumber;

	}

	// 将星期转换为对应的系数 星期日：1，星期一：2，星期二：3，星期三：4，星期四：5，星期五：6，星期六：7
	public static Integer getWeekNum(String strWeek) {
		Integer number = 1;// 默认为星期日
		if ("星期日".equals(strWeek)) {
			number = 1;
		} else if ("星期一".equals(strWeek)) {
			number = 2;
		} else if ("星期二".equals(strWeek)) {
			number = 3;
		} else if ("星期三".equals(strWeek)) {
			number = 4;
		} else if ("星期四".equals(strWeek)) {
			number = 5;
		} else if ("星期五".equals(strWeek)) {
			number = 6;
		} else if ("星期六".equals(strWeek)) {
			number = 7;
		} else {
			number = 1;
		}
		return number;
	}

}