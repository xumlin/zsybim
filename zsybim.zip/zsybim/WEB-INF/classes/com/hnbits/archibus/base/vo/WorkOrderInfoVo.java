package com.hnbits.archibus.base.vo;

import com.hnbits.archibus.base.po.WorkOrderInfo;

public class WorkOrderInfoVo extends WorkOrderInfo{

}
