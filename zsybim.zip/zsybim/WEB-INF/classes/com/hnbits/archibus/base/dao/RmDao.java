package com.hnbits.archibus.base.dao;

import com.hnbits.common.annotation.AnnotationDataSource;

import java.util.List;

import com.hnbits.archibus.AbConstant;
import com.hnbits.archibus.base.vo.FlVo;
import com.hnbits.archibus.base.vo.RmVo;
import com.hnbits.common.dao.BaseDao;

/**
 * 
 * <br>
 * <b>功能：</b>RmDao<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@AnnotationDataSource(datasource="master",schema=AbConstant.DB_SCHEMA)
public interface RmDao extends BaseDao<RmVo>{
}
