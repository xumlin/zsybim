package com.hnbits.archibus.base.action;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;
import com.hnbits.util.MsgUtil;
import com.hnbits.util.SpringHttpUtil;
import com.hnbits.util.StringUtil;
import com.hnbits.util.easyui.GridJsonUtil;
import com.hnbits.archibus.base.vo.EqVo;
import com.hnbits.archibus.base.vo.InspectionRuleVo;
import com.hnbits.archibus.base.vo.WorkOrderVo;
import com.alibaba.fastjson.JSONArray;
import com.hnbits.app.system.vo.TbUserVo;
import com.hnbits.archibus.base.logic.impl.InspectionRuleLogicImpl;
import com.hnbits.archibus.base.logic.impl.WorkOrderLogiclmpl;
import com.hnbits.archibus.base.po.Eq;

@Controller
@RequestMapping("base/inspectionRuleAction")
public class InspectionRuleAction extends BossBaseAction<InspectionRuleVo> {

	private final static Logger log = LoggerFactory.getLogger(InspectionRuleAction.class);

	@Resource(name = "inspectionRuleLogic")
	private InspectionRuleLogicImpl inspectionRuleLogic;

	@Resource(name = "workOrderLogic")
	private WorkOrderLogiclmpl workOrderLogic;

	private static final String page_toList = "jsp/archibus/rule/inspectionRuleList";
	private static final String page_toAdd = "jsp/archibus/rule/inspectionRuleAdd";
	private static final String page_toEdit = "jsp/archibus/rule/inspectionRuleEdit";

	public InspectionRuleAction() {
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}

	@RequestMapping({ "queryAll.do" })
	@ResponseBody
	public String queryAll(HttpServletRequest request, @ModelAttribute("params") InspectionRuleVo vo) throws Exception {
		String category = request.getParameter("category");
		String work_time = request.getParameter("work_time");
		String state1 = StringUtil.trimToNull(request.getParameter("state1"));
		vo = new InspectionRuleVo();
		vo.setCategory(StringUtil.trimToNull(category));
		vo.setWork_time(StringUtil.trimToNull(work_time));
		vo.setState(StringUtil.trimToNull(state1));
		this.log.info("开始查询!");
		String str = null;
		List<InspectionRuleVo> list = null;
		try {
			long rows = getLogic().queryCount(vo);
			list = getLogic().queryList(vo);
			queryListAfter(list);
			str = GridJsonUtil.getDataGridJson(rows, list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.log.debug(str);
		this.log.info("结束查询系统参数配置,返回记录数[" + (list == null ? "null" : Integer.valueOf(list.size())) + "]!");
		return str;
	}

	@RequestMapping({ "queryAllCategory.do" })
	@ResponseBody
	public String queryAllCategory() throws Exception {
		this.log.info("开始查询!");
		String str = null;
		List list = null;
		InspectionRuleVo vo = new InspectionRuleVo();
		try {
			list = this.inspectionRuleLogic.queryAllCategory(vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.log.debug(str);
		this.log.info("结束查询系统参数配置,返回记录数[" + (list == null ? "null" : Integer.valueOf(list.size())) + "]!");
		return JSONArray.toJSONString(list);
	}

	@RequestMapping({ "queryFlByBl.do" })
	@ResponseBody
	public String queryFlByBl() throws Exception {
		this.log.info("开始查询!");
		String str = null;
		List list = null;
		HttpServletRequest req = SpringHttpUtil.getRequest();
		String bl_id = req.getParameter("bl_id");
		InspectionRuleVo vo = new InspectionRuleVo();
		vo.setBl_id(bl_id);
		try {
			list = this.inspectionRuleLogic.queryFlByBl(vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.log.debug(str);
		this.log.info("结束查询系统参数配置,返回记录数[" + (list == null ? "null" : Integer.valueOf(list.size())) + "]!");
		return JSONArray.toJSONString(list);
	}

	@RequestMapping({ "queryRmByFl.do" })
	@ResponseBody
	public String queryRmByFl() throws Exception {
		this.log.info("开始查询!");
		String str = null;
		List list = null;
		HttpServletRequest req = SpringHttpUtil.getRequest();
		String bl_id = req.getParameter("bl_id");
		String fl_id = req.getParameter("fl_id");
		InspectionRuleVo vo = new InspectionRuleVo();
		vo.setBl_id(bl_id);
		vo.setFl_id(fl_id);
		try {
			list = this.inspectionRuleLogic.queryRmByFl(vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.log.debug(str);
		this.log.info("结束查询系统参数配置,返回记录数[" + (list == null ? "null" : Integer.valueOf(list.size())) + "]!");
		return JSONArray.toJSONString(list);
	}

	/**
	 * 新增规则
	 */
	@RequestMapping({ "insert.do", "add.do" })
	@ResponseBody
	public String insert(HttpServletRequest request, @ModelAttribute("params") InspectionRuleVo vo) throws Exception {
		String msg = null;
		try {
			HttpSession session = SpringHttpUtil.getSession();
			TbUserVo user = (TbUserVo) session.getAttribute("SessionUserInfo");
			vo.setState("0");
			vo.setCreate_user(user.getUser_name());
			vo.setCreate_time(new Timestamp(System.currentTimeMillis()));
			initInsert(vo);
			int rows = this.inspectionRuleLogic.insert(vo);
			if (rows > 0) {
				msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("common.action.addOK"), vo);
			} else {
				msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.action.addFail"), vo);
			}
			ddlAfter(vo);
		} catch (Exception e) {
			e.printStackTrace();
			msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.action.addFail"), vo);
		}
		this.log.debug(msg);
		return msg;
	}

	/**
	 * 查询规则
	 */
	@RequestMapping({ "editInspectionRule.do" })
	public String toEdit(HttpServletRequest request, @ModelAttribute("params") InspectionRuleVo vo, ModelMap model)
			throws Exception {
		HttpServletRequest req = SpringHttpUtil.getRequest();
		InspectionRuleVo tvo = this.inspectionRuleLogic.queryOne(vo);
		tvo.setJsnamespace(vo.getJsnamespace());
		model.addAttribute("data", tvo);
		return this.page_toEdit;
	}

	@RequestMapping({ "update.do" })
	@ResponseBody
	public String update(HttpServletRequest request, @ModelAttribute("params") InspectionRuleVo vo) throws Exception {
		HttpServletRequest req = SpringHttpUtil.getRequest();
		String msg = null;
		try {
			int rows = getLogic().update(vo);
			if (rows > 0) {
				msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("common.action.updateOK"), vo);
			} else {
				msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.action.updateFail"), vo);
			}
			ddlAfter(vo);
		} catch (Exception e) {
			e.printStackTrace();
			msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("common.exception"), vo);
		}
		this.log.debug(msg);
		return msg;
	}

	/**
	 * 审核规则产生工单
	 * 
	 * @param request
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping({ "updateStaAndCreateOrders.do" })
	@ResponseBody
	public String updateStaAndCreateOrders(HttpServletRequest request, @ModelAttribute("params") InspectionRuleVo vo,
			ModelMap model) throws Exception {
		HttpServletRequest req = SpringHttpUtil.getRequest();
		HttpSession session = SpringHttpUtil.getSession();
		TbUserVo user = (TbUserVo) session.getAttribute("SessionUserInfo");
		vo.setCheck_user(user.getUser_name());
		vo.setCheck_time(new Timestamp(System.currentTimeMillis()));
		vo.setState("2");
		int row = this.inspectionRuleLogic.update(vo);
		InspectionRuleVo tvo = this.inspectionRuleLogic.queryOne(vo);
		String rmIds = tvo.getRm_id();
		if(StringUtil.trimToNull(rmIds)!=null){
			List list = new ArrayList<>();
			if(rmIds.contains(",")){
				list = Arrays.asList(rmIds.split(",")); 
				
			}else{
				list.add(rmIds);
			}
			tvo.setList(list);
		}
		List<EqVo> eqList = new ArrayList<EqVo>();
		tvo.setBl_id(StringUtil.trimToNull(tvo.getBl_id()));
		eqList = this.inspectionRuleLogic.queryEqList(tvo);
		for (EqVo eqVo : eqList) {

			WorkOrderVo wvo = new WorkOrderVo();
			wvo.setRule_id(StringUtil.trimToNull(tvo.getRule_id()));
			wvo.setWork_type("巡检");// 巡检生成的订单是预订单，创建时间不是现在时间，而是在规则有效时间内满足规则的时间
			Timestamp time = WeekDayUtil.getTime(tvo.getWork_time(), StringUtil.trimToNull(tvo.getRule_unit()),
					StringUtil.trimToNull(tvo.getRule_num()));
			wvo.setCreate_time(time);
			wvo.setSupervisor(StringUtil.trimToNull(user.getUser_name()));
			wvo.setCategory(StringUtil.trimToNull(tvo.getCategory()));
			wvo.setBl_id(StringUtil.trimToNull(tvo.getBl_id()));
			wvo.setFl_id(StringUtil.trimToNull(tvo.getFl_id()));
			wvo.setRm_id(StringUtil.trimToNull(tvo.getRm_id()));
			wvo.setEq_id(StringUtil.trimToNull(eqVo.getEq_id()));
			wvo.setEq_name(StringUtil.trimToNull(eqVo.getUse1()));
			wvo.setPro_level("二级");
			wvo.setProblem_des("定期巡检产生的工单,请及时处理");
			wvo.setState(1);
			workOrderLogic.insert(wvo);

		}
		String msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("common.action.updateOK"), tvo);
		return msg;
	}

	/**
	 * 反申規則，刪除相關工單
	 * @param request
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping({ "updateStaAndDeleteOrders.do" })
	@ResponseBody
	public String updateStaAndDeleteOrders(HttpServletRequest request, @ModelAttribute("params") InspectionRuleVo vo,
			ModelMap model) throws Exception {
		HttpServletRequest req = SpringHttpUtil.getRequest();
		HttpSession session = SpringHttpUtil.getSession();
		TbUserVo user = (TbUserVo) session.getAttribute("SessionUserInfo");
		vo.setRecheck_user(user.getUser_name());
		vo.setRecheck_time(new Timestamp(System.currentTimeMillis()));
		vo.setState("3");
		int row = this.inspectionRuleLogic.update(vo);
		InspectionRuleVo tvo = this.inspectionRuleLogic.queryOne(vo);

		this.inspectionRuleLogic.deleteOrdersByruleId(tvo);

		tvo.setJsnamespace(vo.getJsnamespace());
		String msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("common.action.updateOK"), tvo);
		return msg;
	}

	

	@Override
	public BaseLogic<InspectionRuleVo> getLogic() {
		// TODO Auto-generated method stub
		return inspectionRuleLogic;
	}

	@Override
	protected void queryListAfter(List<InspectionRuleVo> e) throws Exception {
	}

	@Override
	protected void ddlAfter(InspectionRuleVo vo) throws Exception {

	}
}
