package com.hnbits.archibus.base.logic.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hnbits.archibus.base.dao.WorkOrderInfoDao;
import com.hnbits.archibus.base.vo.WorkOrderInfoVo;
import com.hnbits.common.logic.impl.BaseLogicImpl;

@Service("workOrderInfoLogic")
public class WorkOrderInfoLogiclmpl extends BaseLogicImpl<WorkOrderInfoVo,WorkOrderInfoDao>{

	@Resource(name = "workOrderInfoDao")
	@Override
	public void setBaseDao(WorkOrderInfoDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}

}
