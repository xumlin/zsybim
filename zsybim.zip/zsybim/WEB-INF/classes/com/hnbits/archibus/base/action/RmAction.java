package com.hnbits.archibus.base.action;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.hnbits.util.StringUtil;
import com.hnbits.app.BaseAction;
import com.hnbits.util.MsgUtil;
import com.hnbits.util.SpringHttpUtil;
import com.hnbits.util.easyui.GridJsonUtil;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;

import com.hnbits.archibus.base.vo.RmVo;
import com.hnbits.archibus.base.logic.impl.RmLogicImpl;

/**
 * 
 * <br>
 * <b>功能：</b>RmEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Controller
@RequestMapping("base/rmAction") 
public class RmAction extends BossBaseAction<RmVo>{
	
	private final static Logger log= LoggerFactory.getLogger(RmAction.class);
	
	@Resource(name="rmLogic")
	private RmLogicImpl rmLogic; 
	
	
	private static final String page_toList = "jsp/archibus/base/rmList";
	private static final String page_toAdd = "jsp/archibus/base/rmAdd";
	private static final String page_toEdit = "jsp/archibus/base/rmEdit";
	
	public RmAction() {
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}
	
	@Override
	public BaseLogic<RmVo> getLogic() {
		// TODO Auto-generated method stub
		return rmLogic;
	}

	@Override
	protected void queryListAfter(List<RmVo> e) throws Exception {
		
	}

	@Override
	protected void ddlAfter(RmVo vo) throws Exception {
		
	}
}
