package com.hnbits.archibus.base.action;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hnbits.archibus.base.logic.impl.WorkOrderInfoLogiclmpl;
import com.hnbits.archibus.base.vo.WorkOrderInfoVo;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;

@Controller
@RequestMapping("base/workOrderInfoAction") 
public class WorkOrderInfoAction extends BossBaseAction<WorkOrderInfoVo>{
	private final static Logger log= LoggerFactory.getLogger(WorkOrderInfoAction.class);
	
	@Resource(name="workOrderInfoLogic")
	private WorkOrderInfoLogiclmpl workOrderInfoLogic;

	@Override
	protected void ddlAfter(WorkOrderInfoVo vo) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BaseLogic<WorkOrderInfoVo> getLogic() {
		// TODO Auto-generated method stub
		return workOrderInfoLogic;
	}

	@Override
	protected void queryListAfter(List<WorkOrderInfoVo> e) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
