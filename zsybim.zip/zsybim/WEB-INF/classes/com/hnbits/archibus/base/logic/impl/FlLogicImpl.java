package com.hnbits.archibus.base.logic.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.hnbits.archibus.base.dao.FlDao;
import com.hnbits.archibus.base.vo.FlVo;
import com.hnbits.common.logic.impl.BaseLogicImpl;


/**
 * 
 * <br>
 * <b>功能：</b>FlEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Service("flLogic")
public class FlLogicImpl extends BaseLogicImpl<FlVo, FlDao>{
	private final static Logger log= Logger.getLogger(FlLogicImpl.class);
	
	
	@Resource(name = "flDao")
	@Override
	public void setBaseDao(FlDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}
	
	public List<FlVo> queryFlTree(FlVo vo) throws Exception{
		return this.dao.queryFlTree(vo);
	}
	
	public List<FlVo> queryLeaseFlTree(FlVo vo) throws Exception{
		return this.dao.queryLeaseFlTree(vo);
	}
	
	public List<FlVo> queryLeaseExpireFlTree(FlVo vo) throws Exception{
		return this.dao.queryLeaseExpireFlTree(vo);
	}
	
	public List<FlVo> queryLeaseNoneFlTree(FlVo vo) throws Exception{
		return this.dao.queryLeaseNoneFlTree(vo);
	}

}
