package com.hnbits.archibus.base.vo;

import java.util.List;

import com.hnbits.archibus.base.po.InspectionRule;

public class InspectionRuleVo extends InspectionRule {
	
	private String temp_time;
	
	private List list;

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public String getTemp_time() {
		return temp_time;
	}

	public void setTemp_time(String temp_time) {
		this.temp_time = temp_time;
	}

	


	
}
