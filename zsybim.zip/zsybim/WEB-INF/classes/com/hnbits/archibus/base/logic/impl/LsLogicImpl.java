package com.hnbits.archibus.base.logic.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hnbits.archibus.base.dao.LsDao;
import com.hnbits.archibus.base.vo.LsVo;
import com.hnbits.common.logic.impl.BaseLogicImpl;

@Service("lsLogic")
public class LsLogicImpl extends BaseLogicImpl<LsVo, LsDao>{

	@Resource(name = "lsDao")
	public void setBaseDao(LsDao dao) {
		this.dao = dao;
	}

}
