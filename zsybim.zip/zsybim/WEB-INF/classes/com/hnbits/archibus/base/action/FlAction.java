package com.hnbits.archibus.base.action;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hnbits.archibus.base.logic.impl.FlLogicImpl;
import com.hnbits.archibus.base.vo.FlVo;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;
import com.hnbits.util.SpringHttpUtil;
import com.hnbits.util.StringUtil;
import com.hnbits.util.easyui.Tree;

/**
 * 
 * <br>
 * <b>功能：</b>FlEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Controller
@RequestMapping("base/flAction") 
public class FlAction extends BossBaseAction<FlVo>{
	
	private final static Logger log= LoggerFactory.getLogger(FlAction.class);
	
	@Resource(name="flLogic")
	private FlLogicImpl flLogic; 
	
	
	private static final String page_toList = "jsp/archibus/base/flList";
	private static final String page_toAdd = "jsp/archibus/base/flAdd";
	private static final String page_toEdit = "jsp/archibus/base/flEdit";
	
	public FlAction() {
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}
	
	@Override
	public BaseLogic<FlVo> getLogic() {
		// TODO Auto-generated method stub
		return flLogic;
	}
	
	@RequestMapping("queryTree.do")
	@ResponseBody
	public String queryTree() {
		log.info("开始查询楼层信息树!");
		String str = null;
		List<FlVo> list = null;
		try {
			HttpServletRequest req = SpringHttpUtil.getRequest();
			String rootDeptId = "0";
			String treetype = req.getParameter("treetype");
			FlVo vo = (FlVo)SpringHttpUtil.getParameterVo(req, FlVo.class, true);
			if(!StringUtil.isEmpty(treetype) && treetype.equalsIgnoreCase("lease")){
				list = this.flLogic.queryLeaseFlTree(vo);
			}
			else if(!StringUtil.isEmpty(treetype) && treetype.equalsIgnoreCase("leaseexpire")){
				list = this.flLogic.queryLeaseExpireFlTree(vo);			
			}
			else if(!StringUtil.isEmpty(treetype) && treetype.equalsIgnoreCase("leasenone")){
				list = this.flLogic.queryLeaseNoneFlTree(vo);
			}
			else{
				list = this.flLogic.queryFlTree(vo);
			}
			List<String> attrList = new ArrayList<String>();
			attrList.add("parent_id");
			attrList.add("level");
			attrList.add("bl_id");
			attrList.add("fl_id");
			Tree deptTree = new Tree("id", "parent_id", "name", "checked", "state", attrList, list);
			str = deptTree.buildJson(rootDeptId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.debug("tree:" + str);
		log.info("结束查询楼层信息树,返回记录数[" + ((null == list) ? "null" : list.size()) + "]!");
		return str;
	}

	@Override
	protected void queryListAfter(List<FlVo> e) throws Exception {
		
	}

	@Override
	protected void ddlAfter(FlVo vo) throws Exception {
		
	}
}
