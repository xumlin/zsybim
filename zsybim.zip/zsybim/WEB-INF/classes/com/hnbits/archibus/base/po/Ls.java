package com.hnbits.archibus.base.po;

import com.hnbits.app.PagerModel;

public class Ls extends PagerModel{
	
	private static final long serialVersionUID = 5921108310046053576L;
	
	private String ls_id;
	private String description;
	private Integer use_as_template;
	private String pr_id;
	private String eq_id;
	private String bl_id;
	private String ac_id;
	
	public String getPr_id() {
		return pr_id;
	}
	public void setPr_id(String pr_id) {
		this.pr_id = pr_id;
	}
	public String getEq_id() {
		return eq_id;
	}
	public void setEq_id(String eq_id) {
		this.eq_id = eq_id;
	}
	public String getBl_id() {
		return bl_id;
	}
	public void setBl_id(String bl_id) {
		this.bl_id = bl_id;
	}
	public String getAc_id() {
		return ac_id;
	}
	public void setAc_id(String ac_id) {
		this.ac_id = ac_id;
	}
	public String getLs_id() {
		return ls_id;
	}
	public void setLs_id(String ls_id) {
		this.ls_id = ls_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getUse_as_template() {
		return use_as_template;
	}
	public void setUse_as_template(Integer use_as_template) {
		this.use_as_template = use_as_template;
	}
}
