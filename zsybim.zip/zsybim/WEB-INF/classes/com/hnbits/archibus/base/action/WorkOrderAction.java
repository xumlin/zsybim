package com.hnbits.archibus.base.action;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hnbits.app.system.vo.TbUserVo;
import com.hnbits.archibus.base.logic.impl.InspectionRuleLogicImpl;
import com.hnbits.archibus.base.logic.impl.WorkOrderLogiclmpl;
import com.hnbits.archibus.base.vo.EqVo;
import com.hnbits.archibus.base.vo.InspectionRuleVo;
import com.hnbits.archibus.base.vo.WorkOrderVo;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;
import com.hnbits.util.MsgUtil;
import com.hnbits.util.SpringHttpUtil;
import com.hnbits.util.StringUtil;
import com.hnbits.util.easyui.GridJsonUtil;

@Controller
@RequestMapping("base/workOrderAction") 
public class WorkOrderAction extends BossBaseAction<WorkOrderVo>{

	private final static Logger log= LoggerFactory.getLogger(WorkOrderAction.class);
	
	@Resource(name="workOrderLogic")
	private WorkOrderLogiclmpl workOrderLogic;
	
	@Resource(name = "inspectionRuleLogic")
	private InspectionRuleLogicImpl inspectionRuleLogic;
	
	 
	
	private static final String page_toList = "jsp/archibus/base/workOrder";
	private static final String page_toAdd = "jsp/archibus/base/workOrderAdd";
	private static final String page_toEdit = "jsp/archibus/base/workOrderEdit";
	
	public WorkOrderAction() {
		/*HttpServletRequest req = SpringHttpUtil.getRequest();
		 String mString = req.getParameter("params");
		 System.out.print(mString);*/
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}
	 
	/**
	 * 结单按规则产生新工单
	 * 
	 * @param request
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping({ "finish.do" })
	@ResponseBody
	public String finihs(HttpServletRequest request, @ModelAttribute("params") WorkOrderVo vo,
			ModelMap model) throws Exception {
		HttpServletRequest req = SpringHttpUtil.getRequest();
		/*String work_id = req.getParameter("work_id");
		vo.setWork_id(work_id);*/
		HttpSession session = SpringHttpUtil.getSession();
		TbUserVo user = (TbUserVo) session.getAttribute("SessionUserInfo");
		vo.setState(-2);
		int rows = this.workOrderLogic.update(vo);
		vo = this.workOrderLogic.queryOne(vo);
		if(StringUtil.trimToNull(vo.getWork_type()).equals("巡检")){
			InspectionRuleVo tvo = new InspectionRuleVo();
			tvo.setRule_id(StringUtil.trimToNull(vo.getRule_id()));
		    tvo = this.inspectionRuleLogic.queryOne(tvo);
			WorkOrderVo wvo = new WorkOrderVo();
			wvo.setRule_id(StringUtil.trimToNull(tvo.getRule_id()));
			wvo.setWork_type("巡检");// 巡检生成的订单是预订单，创建时间不是现在时间，而是在规则有效时间内满足规则的时间
			Timestamp time = WeekDayUtil.getTime(tvo.getWork_time(), StringUtil.trimToNull(tvo.getRule_unit()),
					StringUtil.trimToNull(tvo.getRule_num()));
			wvo.setCreate_time(time);
			wvo.setSupervisor(StringUtil.trimToNull(user.getUser_name()));
			wvo.setCategory(StringUtil.trimToNull(tvo.getCategory()));
			wvo.setBl_id(StringUtil.trimToNull(tvo.getBl_id()));
			wvo.setFl_id(StringUtil.trimToNull(tvo.getFl_id()));
			wvo.setRm_id(StringUtil.trimToNull(tvo.getRm_id()));
			wvo.setEq_id(StringUtil.trimToNull(vo.getEq_id()));
			wvo.setEq_name(StringUtil.trimToNull(vo.getEq_name()));
			wvo.setPro_level("二级");
			wvo.setProblem_des("定期巡检产生的工单,请及时处理");
			wvo.setState(1);
			workOrderLogic.insert(wvo);
		}

		String msg = "";
		if (rows > 0) {
			msg = MsgUtil.getOutMsg(true, MsgUtil.getConfigMsg("结单完毕"), vo);
		} else {
			msg = MsgUtil.getOutMsg(false, MsgUtil.getConfigMsg("结单失败"), vo);
		}
		return msg;
	}

	
	@Override
	public BaseLogic<WorkOrderVo> getLogic() {
		// TODO Auto-generated method stub
		return workOrderLogic;
	}

	@Override
	protected void queryListAfter(List<WorkOrderVo> e) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void ddlAfter(WorkOrderVo vo) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
}
