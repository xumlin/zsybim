package com.hnbits.archibus.base.logic.impl;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.hnbits.archibus.base.dao.WorkOrderDao;
import com.hnbits.archibus.base.vo.WorkOrderVo;
import com.hnbits.common.logic.impl.BaseLogicImpl;

@Service("workOrderLogic")
public class WorkOrderLogiclmpl extends BaseLogicImpl<WorkOrderVo,WorkOrderDao>{
	private final static Logger log= Logger.getLogger(WorkOrderLogiclmpl.class);

	@Resource(name = "workOrderDao")
	@Override
	public void setBaseDao(WorkOrderDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}

}
