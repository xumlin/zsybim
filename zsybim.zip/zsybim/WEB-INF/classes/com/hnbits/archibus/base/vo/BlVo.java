package com.hnbits.archibus.base.vo;

import com.hnbits.archibus.base.po.Bl;

/**
 * 
 * <br>
 * <b>功能：</b>BlVo<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
public class BlVo extends Bl{
		
}
