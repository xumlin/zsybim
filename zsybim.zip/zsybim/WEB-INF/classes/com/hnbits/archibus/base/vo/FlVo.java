package com.hnbits.archibus.base.vo;

import com.hnbits.archibus.base.po.Fl;

/**
 * 
 * <br>
 * <b>功能：</b>FlVo<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
public class FlVo extends Fl{
	
	private static final long serialVersionUID = -7011877291355860788L;
	private String id;
	private String name;
	private String parent_id;
	private String level;
	private String checked;
	private String state;
	
	private String ls_id;
	private String ls_from_date;
	private String ls_to_date;
	public String getLs_from_date() {
		return ls_from_date;
	}
	public void setLs_from_date(String ls_from_date) {
		this.ls_from_date = ls_from_date;
	}
	public String getLs_to_date() {
		return ls_to_date;
	}
	public void setLs_to_date(String ls_to_date) {
		this.ls_to_date = ls_to_date;
	}
	public String getLs_id() {
		return ls_id;
	}
	public void setLs_id(String ls_id) {
		this.ls_id = ls_id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParent_id() {
		return parent_id;
	}
	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getChecked() {
		return checked;
	}
	public void setChecked(String checked) {
		this.checked = checked;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
