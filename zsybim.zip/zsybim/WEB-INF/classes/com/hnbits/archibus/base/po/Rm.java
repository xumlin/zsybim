package com.hnbits.archibus.base.po;

import com.hnbits.app.PagerModel;
/**
 * 
 * <br>
 * <b>功能：</b>RmEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
public class Rm extends PagerModel{
		//null	private Float area;	//null	private Float area_alloc;	//null	private Double area_chargable;	//null	private Float area_comn;	//null	private Float area_comn_nocup;	//null	private Float area_comn_ocup;	//null	private Integer cap_em;	//null	private Float cost_sqft;	//null	private java.util.Date date_last_surveyed;	//null	private Double lat;	//null	private Integer hotelable;	//null	private Integer geo_objectid;	//null	private String extension;	//null	private String ehandle;	//null	private String dwgname;	//null	private String dv_id;	//null	private String dp_id;	//null	private Float count_em;	//null	private String survey_comments_rm;	//null	private String rm_use;	//null	private String rm_type;	//null	private String rm_std;	//null	private String rm_cat;	//null	private Integer reservable;	//null	private String recovery_status;	//null	private String prorate;	//null	private String phone;	//null	private String transfer_status;	//null	private String tc_level;	//null	private String survey_redline_rm;	//null	private String survey_photo;	//null	private String org_id;	//null	private String option2;	//null	private String option1;	//null	private String name;	//null	private String ls_id;	//null	private Double lon;	//null	private Double length;	//null	private String layer_name;	//null	private Double cost;	//null	private Float area_comn_rm;	//null	private Float area_comn_serv;	//null	private Float area_manual;	//null	private Float area_unalloc;	//null	private String bl_id;	//null	private String fl_id;	//房间ID	private String rm_id;
	//房间类别描述
	private String des_cat;
	//房间类型	private String des_type;
	//业务部名
	private String dv_name;
	//部门名
	private String dp_name;
	//租金	private String amount_base_rent;
	//租约编码
	private String lsId;
	//房间标准
	private String des_std;
	
		public String getDes_std() {
		return des_std;
	}
	public void setDes_std(String des_std) {
		this.des_std = des_std;
	}
	public String getLsId() {
		return lsId;
	}
	public void setLsId(String lsId) {
		this.lsId = lsId;
	}
	public String getAmount_base_rent() {
		return amount_base_rent;
	}
	public void setAmount_base_rent(String amount_base_rent) {
		this.amount_base_rent = amount_base_rent;
	}
	public String getDv_name() {
		return dv_name;
	}
	public void setDv_name(String dv_name) {
		this.dv_name = dv_name;
	}
	public String getDp_name() {
		return dp_name;
	}
	public void setDp_name(String dp_name) {
		this.dp_name = dp_name;
	}
	public String getDes_cat() {
		return des_cat;
	}
	public void setDes_cat(String des_cat) {
		this.des_cat = des_cat;
	}
	public String getDes_type() {
		return des_type;
	}
	public void setDes_type(String des_type) {
		this.des_type = des_type;
	}
	public Float getArea() {	    return this.area;	}	public void setArea(Float area) {	    this.area=area;	}	public Float getArea_alloc() {	    return this.area_alloc;	}	public void setArea_alloc(Float area_alloc) {	    this.area_alloc=area_alloc;	}	public Double getArea_chargable() {	    return this.area_chargable;	}	public void setArea_chargable(Double area_chargable) {	    this.area_chargable=area_chargable;	}	public Float getArea_comn() {	    return this.area_comn;	}	public void setArea_comn(Float area_comn) {	    this.area_comn=area_comn;	}	public Float getArea_comn_nocup() {	    return this.area_comn_nocup;	}	public void setArea_comn_nocup(Float area_comn_nocup) {	    this.area_comn_nocup=area_comn_nocup;	}	public Float getArea_comn_ocup() {	    return this.area_comn_ocup;	}	public void setArea_comn_ocup(Float area_comn_ocup) {	    this.area_comn_ocup=area_comn_ocup;	}	public Integer getCap_em() {	    return this.cap_em;	}	public void setCap_em(Integer cap_em) {	    this.cap_em=cap_em;	}	public Float getCost_sqft() {	    return this.cost_sqft;	}	public void setCost_sqft(Float cost_sqft) {	    this.cost_sqft=cost_sqft;	}	public java.util.Date getDate_last_surveyed() {	    return this.date_last_surveyed;	}	public void setDate_last_surveyed(java.util.Date date_last_surveyed) {	    this.date_last_surveyed=date_last_surveyed;	}	public Double getLat() {	    return this.lat;	}	public void setLat(Double lat) {	    this.lat=lat;	}	public Integer getHotelable() {	    return this.hotelable;	}	public void setHotelable(Integer hotelable) {	    this.hotelable=hotelable;	}	public Integer getGeo_objectid() {	    return this.geo_objectid;	}	public void setGeo_objectid(Integer geo_objectid) {	    this.geo_objectid=geo_objectid;	}	public String getExtension() {	    return this.extension;	}	public void setExtension(String extension) {	    this.extension=extension;	}	public String getEhandle() {	    return this.ehandle;	}	public void setEhandle(String ehandle) {	    this.ehandle=ehandle;	}	public String getDwgname() {	    return this.dwgname;	}	public void setDwgname(String dwgname) {	    this.dwgname=dwgname;	}	public String getDv_id() {	    return this.dv_id;	}	public void setDv_id(String dv_id) {	    this.dv_id=dv_id;	}	public String getDp_id() {	    return this.dp_id;	}	public void setDp_id(String dp_id) {	    this.dp_id=dp_id;	}	public Float getCount_em() {	    return this.count_em;	}	public void setCount_em(Float count_em) {	    this.count_em=count_em;	}	public String getSurvey_comments_rm() {	    return this.survey_comments_rm;	}	public void setSurvey_comments_rm(String survey_comments_rm) {	    this.survey_comments_rm=survey_comments_rm;	}	public String getRm_use() {	    return this.rm_use;	}	public void setRm_use(String rm_use) {	    this.rm_use=rm_use;	}	public String getRm_type() {	    return this.rm_type;	}	public void setRm_type(String rm_type) {	    this.rm_type=rm_type;	}	public String getRm_std() {	    return this.rm_std;	}	public void setRm_std(String rm_std) {	    this.rm_std=rm_std;	}	public String getRm_cat() {	    return this.rm_cat;	}	public void setRm_cat(String rm_cat) {	    this.rm_cat=rm_cat;	}	public Integer getReservable() {	    return this.reservable;	}	public void setReservable(Integer reservable) {	    this.reservable=reservable;	}	public String getRecovery_status() {	    return this.recovery_status;	}	public void setRecovery_status(String recovery_status) {	    this.recovery_status=recovery_status;	}	public String getProrate() {	    return this.prorate;	}	public void setProrate(String prorate) {	    this.prorate=prorate;	}	public String getPhone() {	    return this.phone;	}	public void setPhone(String phone) {	    this.phone=phone;	}	public String getTransfer_status() {	    return this.transfer_status;	}	public void setTransfer_status(String transfer_status) {	    this.transfer_status=transfer_status;	}	public String getTc_level() {	    return this.tc_level;	}	public void setTc_level(String tc_level) {	    this.tc_level=tc_level;	}	public String getSurvey_redline_rm() {	    return this.survey_redline_rm;	}	public void setSurvey_redline_rm(String survey_redline_rm) {	    this.survey_redline_rm=survey_redline_rm;	}	public String getSurvey_photo() {	    return this.survey_photo;	}	public void setSurvey_photo(String survey_photo) {	    this.survey_photo=survey_photo;	}	public String getOrg_id() {	    return this.org_id;	}	public void setOrg_id(String org_id) {	    this.org_id=org_id;	}	public String getOption2() {	    return this.option2;	}	public void setOption2(String option2) {	    this.option2=option2;	}	public String getOption1() {	    return this.option1;	}	public void setOption1(String option1) {	    this.option1=option1;	}	public String getName() {	    return this.name;	}	public void setName(String name) {	    this.name=name;	}	public String getLs_id() {	    return this.ls_id;	}	public void setLs_id(String ls_id) {	    this.ls_id=ls_id;	}	public Double getLon() {	    return this.lon;	}	public void setLon(Double lon) {	    this.lon=lon;	}	public Double getLength() {	    return this.length;	}	public void setLength(Double length) {	    this.length=length;	}	public String getLayer_name() {	    return this.layer_name;	}	public void setLayer_name(String layer_name) {	    this.layer_name=layer_name;	}	public Double getCost() {	    return this.cost;	}	public void setCost(Double cost) {	    this.cost=cost;	}	public Float getArea_comn_rm() {	    return this.area_comn_rm;	}	public void setArea_comn_rm(Float area_comn_rm) {	    this.area_comn_rm=area_comn_rm;	}	public Float getArea_comn_serv() {	    return this.area_comn_serv;	}	public void setArea_comn_serv(Float area_comn_serv) {	    this.area_comn_serv=area_comn_serv;	}	public Float getArea_manual() {	    return this.area_manual;	}	public void setArea_manual(Float area_manual) {	    this.area_manual=area_manual;	}	public Float getArea_unalloc() {	    return this.area_unalloc;	}	public void setArea_unalloc(Float area_unalloc) {	    this.area_unalloc=area_unalloc;	}	public String getBl_id() {	    return this.bl_id;	}	public void setBl_id(String bl_id) {	    this.bl_id=bl_id;	}	public String getFl_id() {	    return this.fl_id;	}	public void setFl_id(String fl_id) {	    this.fl_id=fl_id;	}	public String getRm_id() {	    return this.rm_id;	}	public void setRm_id(String rm_id) {	    this.rm_id=rm_id;	}
}

