package com.hnbits.archibus.base.po;

import java.sql.Timestamp;

import com.hnbits.app.PagerModel;

public class InspectionRule extends PagerModel {
	
	private String rule_id;
	
	private String category;
	
	private String bl_id;
	
	private String fl_id;
	
	private String rm_id;
	
	private String rule_type;
	
	private String rule_unit;
	
	private String rule_num;
	
	private String work_time;
	
	private String state;
	
	private Timestamp create_time;
	
	private String create_user;
	
	private Timestamp check_time;
	
	private String check_user;
	
	private Timestamp recheck_time;
	
	private String recheck_user;

	public String getRule_id() {
		return rule_id;
	}

	public void setRule_id(String rule_id) {
		this.rule_id = rule_id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBl_id() {
		return bl_id;
	}

	public void setBl_id(String bl_id) {
		this.bl_id = bl_id;
	}

	public String getFl_id() {
		return fl_id;
	}

	public void setFl_id(String fl_id) {
		this.fl_id = fl_id;
	}

	public String getRm_id() {
		return rm_id;
	}

	public void setRm_id(String rm_id) {
		this.rm_id = rm_id;
	}

	public String getRule_type() {
		return rule_type;
	}

	public void setRule_type(String rule_type) {
		this.rule_type = rule_type;
	}

	public String getWork_time() {
		return work_time;
	}

	public void setWork_time(String work_time) {
		this.work_time = work_time;
	}

	public String getRule_unit() {
		return rule_unit;
	}

	public void setRule_unit(String rule_unit) {
		this.rule_unit = rule_unit;
	}

	public String getRule_num() {
		return rule_num;
	}

	public void setRule_num(String rule_num) {
		this.rule_num = rule_num;
	}

	

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCreate_user() {
		return create_user;
	}

	public void setCreate_user(String create_user) {
		this.create_user = create_user;
	}


	public String getCheck_user() {
		return check_user;
	}

	public void setCheck_user(String check_user) {
		this.check_user = check_user;
	}

	public Timestamp getCreate_time() {
		return create_time;
	}

	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}

	public Timestamp getCheck_time() {
		return check_time;
	}

	public void setCheck_time(Timestamp check_time) {
		this.check_time = check_time;
	}

	public Timestamp getRecheck_time() {
		return recheck_time;
	}

	public void setRecheck_time(Timestamp recheck_time) {
		this.recheck_time = recheck_time;
	}

	public String getRecheck_user() {
		return recheck_user;
	}

	public void setRecheck_user(String recheck_user) {
		this.recheck_user = recheck_user;
	}
	
	
	


}
