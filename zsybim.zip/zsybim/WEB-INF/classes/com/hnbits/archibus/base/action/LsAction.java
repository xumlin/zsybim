package com.hnbits.archibus.base.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hnbits.archibus.base.logic.impl.LsLogicImpl;
import com.hnbits.archibus.base.vo.LsVo;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;

@Controller
@RequestMapping("base/lsAction") 
public class LsAction extends BossBaseAction<LsVo>{
	
	@Resource(name="lsLogic")
	private LsLogicImpl lsLogic; 
	
	@Override
	public BaseLogic<LsVo> getLogic() {
		// TODO Auto-generated method stub
		return lsLogic;
	}

	@Override
	protected void queryListAfter(List<LsVo> e) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void ddlAfter(LsVo vo) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
