package com.hnbits.archibus.base.logic.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Service;

import com.hnbits.common.logic.impl.BaseLogicImpl;
import com.hnbits.archibus.base.vo.EqVo;
import com.hnbits.archibus.base.vo.InspectionRuleVo;
import com.hnbits.archibus.base.dao.InspectionRuleDao;
import com.hnbits.archibus.base.po.Eq;

@Service("inspectionRuleLogic")
public class InspectionRuleLogicImpl extends BaseLogicImpl<InspectionRuleVo, InspectionRuleDao>{
	private final static Logger log= Logger.getLogger(InspectionRuleLogicImpl.class);
	
	
	@Resource(name = "inspectionRuleDao")
	@Override
	public void setBaseDao(InspectionRuleDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}


	public List queryAllCategory(InspectionRuleVo vo) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.queryAllCategory(vo);
	}


	public List queryFlByBl(InspectionRuleVo vo) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.queryFlByBl(vo);
	}


	public List queryRmByFl(InspectionRuleVo vo) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.queryRmByFl(vo);
	}


	public List<EqVo> queryEqList(InspectionRuleVo vo) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.queryEqList(vo);
	}


	public void deleteOrdersByruleId(InspectionRuleVo vo) throws Exception {
		// TODO Auto-generated method stub
		 this.dao.deleteOrdersByruleId(vo);
	}

}
