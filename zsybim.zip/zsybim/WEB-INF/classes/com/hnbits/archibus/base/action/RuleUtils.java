package com.hnbits.archibus.base.action;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;

public class RuleUtils {
	/**
	 * 
	 * @param time		
	 * @param ruleType	规则类型（固定周期;固定时间）
	 * @param ruleUnit	规则单位（天；每周；每月；每季；每年）
	 * @param ruleNum	规则数量
	 * @return
	 */
	public static Date getTime(String time, String ruleType, String ruleUnit, String ruleNum) {
		if ("固定周期".equals(ruleType)) {
			
		}else if ("固定时间".equals(ruleType)) {
			String t;
			if ("天".equals(ruleUnit)) {
				LocalDate localData = LocalDate.parse(time).plusDays(Long.valueOf(ruleNum));
				return localDate2Date(localData);
			}else if ("每周".equals(ruleUnit)) {
				
			}else if ("每月".equals(ruleUnit)) {
				
			}else if ("每季".equals(ruleUnit)) {
				
			}else if ("每年".equals(ruleUnit)) {
				
			}
		}
		return null;
	}
	
	/**
     * LocalDate转Date
     * @param localDate
     * @return
     */
    public static Date localDate2Date(LocalDate localDate) {
        if(null == localDate) {
            return null;
        }
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
        return Date.from(zonedDateTime.toInstant());
    }
    

}
