package com.hnbits.archibus.base.vo;

import com.hnbits.archibus.base.po.Eq;

/**
 * 
 * <br>
 * <b>功能：</b>EqVo<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
public class EqVo extends Eq{
	
	private String id;
	private String name;
	private String parent_id;
	private String level;
	private String checked;
	private String state;
	private String dwgname;
	private String rm_type;
	private String rm_cat;
	private String rm_id;
	
	public String getRm_id() {
		return rm_id;
	}
	public void setRm_id(String rm_id) {
		this.rm_id = rm_id;
	}
	public String getDwgname() {
		return dwgname;
	}
	public void setDwgname(String dwgname) {
		this.dwgname = dwgname;
	}
	public String getRm_type() {
		return rm_type;
	}
	public void setRm_type(String rm_type) {
		this.rm_type = rm_type;
	}
	public String getRm_cat() {
		return rm_cat;
	}
	public void setRm_cat(String rm_cat) {
		this.rm_cat = rm_cat;
	}
	public String getChecked() {
		return checked;
	}
	public void setChecked(String checked) {
		this.checked = checked;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParent_id() {
		return parent_id;
	}
	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	
}
