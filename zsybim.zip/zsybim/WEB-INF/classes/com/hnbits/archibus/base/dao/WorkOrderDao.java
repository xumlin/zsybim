package com.hnbits.archibus.base.dao;

import com.hnbits.archibus.AbConstant;
import com.hnbits.archibus.base.vo.WorkOrderVo;
import com.hnbits.common.annotation.AnnotationDataSource;
import com.hnbits.common.dao.BaseDao;

@AnnotationDataSource(datasource="master",schema=AbConstant.DB_SCHEMA)
public interface WorkOrderDao extends BaseDao<WorkOrderVo>{

}
