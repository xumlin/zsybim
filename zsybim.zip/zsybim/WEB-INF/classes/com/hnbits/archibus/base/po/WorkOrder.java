package com.hnbits.archibus.base.po;

import com.hnbits.app.PagerModel;

public class WorkOrder extends PagerModel{

	private String work_id;    //工单id
	private String rule_id;    //巡检规则id
	private String work_type;  //工单类型（巡检；应急）
	private java.util.Date create_time;  //创建时间
	private String supervisor; //责任人
	private String category;   //设备类型
	private String bl_id;      //大厦id
	private String fl_id;      //楼层id
	private String rm_id;      //房间号
	private String eq_id;      //设备编号
	private String eq_name;    //设备名称
	private String pro_level;  //问题级别
	private String problem_des;//问题描述
	private int state;     //工单状态（0：新建；1：已申请；2：已审核；3：反审；4：维修中；5：已完成；-1：关闭） 
	public String getWork_id() {
		return work_id;
	}
	public void setWork_id(String work_id) {
		this.work_id = work_id;
	}
	public String getRule_id() {
		return rule_id;
	}
	public void setRule_id(String rule_id) {
		this.rule_id = rule_id;
	}
	public String getWork_type() {
		return work_type;
	}
	public void setWork_type(String work_type) {
		this.work_type = work_type;
	}
	public java.util.Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(java.util.Date create_time) {
		this.create_time = create_time;
	}
	public String getSupervisor() {
		return supervisor;
	}
	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBl_id() {
		return bl_id;
	}
	public void setBl_id(String bl_id) {
		this.bl_id = bl_id;
	}
	public String getFl_id() {
		return fl_id;
	}
	public void setFl_id(String fl_id) {
		this.fl_id = fl_id;
	}
	public String getRm_id() {
		return rm_id;
	}
	public void setRm_id(String rm_id) {
		this.rm_id = rm_id;
	}
	public String getEq_id() {
		return eq_id;
	}
	public void setEq_id(String eq_id) {
		this.eq_id = eq_id;
	}
	public String getEq_name() {
		return eq_name;
	}
	public void setEq_name(String eq_name) {
		this.eq_name = eq_name;
	}
	public String getPro_level() {
		return pro_level;
	}
	public void setPro_level(String pro_level) {
		this.pro_level = pro_level;
	}
	public String getProblem_des() {
		return problem_des;
	}
	public void setProblem_des(String problem_des) {
		this.problem_des = problem_des;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	
	
}
