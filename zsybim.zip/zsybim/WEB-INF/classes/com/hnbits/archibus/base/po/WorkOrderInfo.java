package com.hnbits.archibus.base.po;

import com.hnbits.app.PagerModel;

public class WorkOrderInfo extends PagerModel{
	private String info_id;      //明细id
	private String work_id;      //工单id
	private java.util.Date date_time;   //流程执行时间
	private String user_name;   //流程负责人
	private Integer state;       //工单状态
	private String description;  //操作描述
	private String solution;     //解决办法
	private String pre_measure;  //预防措施
	public String getInfo_id() {
		return info_id;
	}
	public void setInfo_id(String info_id) {
		this.info_id = info_id;
	}
	public String getWork_id() {
		return work_id;
	}
	public void setWork_id(String work_id) {
		this.work_id = work_id;
	}
	public java.util.Date getDate_time() {
		return date_time;
	}
	public void setDate_time(java.util.Date date_time) {
		this.date_time = date_time;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSolution() {
		return solution;
	}
	public void setSolution(String solution) {
		this.solution = solution;
	}
	public String getPre_measure() {
		return pre_measure;
	}
	public void setPre_measure(String pre_measure) {
		this.pre_measure = pre_measure;
	}
	
	

}
