package com.hnbits.archibus;

public class AbConstant {
	
	public final static String DB_SCHEMA = "ZSY.afm";

}
