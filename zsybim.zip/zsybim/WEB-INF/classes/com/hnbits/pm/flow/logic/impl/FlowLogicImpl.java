package com.hnbits.pm.flow.logic.impl;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.hnbits.app.workflow.IFlowService;
import com.hnbits.common.logic.impl.BaseLogicImpl;
import com.hnbits.pm.flow.dao.FlowDao;
import com.hnbits.pm.flow.vo.FlowVo;


/**
 * 
 * <br>
 * <b>功能：</b>FlowEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Service("flowLogic")
public class FlowLogicImpl extends BaseLogicImpl<FlowVo, FlowDao> implements IFlowService{
	private final static Logger log= Logger.getLogger(FlowLogicImpl.class);
	
	
	@Resource(name = "flowDao")
	@Override
	public void setBaseDao(FlowDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}


	public int insertEntity(Object entity) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.insert((FlowVo)entity);
		//return 0;
	}


	public int updateEntityBizKey(Object entity) throws Exception {
		// TODO Auto-generated method stub
		return this.dao.updateByBizKey((FlowVo)entity);
	}

}
