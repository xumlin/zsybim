package com.hnbits.pm.flow.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLinkType;
import org.activiti.engine.task.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.hnbits.app.system.vo.TbUserVo;
import com.hnbits.app.workflow.extend.WorkflowVariable;
import com.hnbits.app.workflow.logic.impl.FlowAssigneeService;
import com.hnbits.app.workflow.po.TbFlowAssignee;
import com.hnbits.app.workflow.util.WorkflowUtils;
import com.hnbits.base.BossBaseAction;
import com.hnbits.common.logic.BaseLogic;
import com.hnbits.pm.flow.logic.impl.FlowLogicImpl;
import com.hnbits.pm.flow.vo.FlowVo;
import com.hnbits.util.MsgUtil;
import com.hnbits.util.ReflectionUtil;
import com.hnbits.util.SessionUserUtil;
import com.hnbits.util.StringUtil;

/**
 * 
 * <br>
 * <b>功能：</b>FlowEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@Controller
@RequestMapping("flow/flowAction") 
public class FlowAction extends BossBaseAction<FlowVo>{
	
	private final static Logger log= LoggerFactory.getLogger(FlowAction.class);
	
	@Resource(name="flowLogic")
	private FlowLogicImpl flowLogic; 
	
	@Autowired(required = false)
	private TaskService taskService;
	
	@Autowired(required = false)
	private FlowAssigneeService flowAssigneeService;
	
	private static final String page_toList = "jsp/flow/flowList";
	private static final String page_toAdd = "jsp/flow/flowAdd";
	private static final String page_toEdit = "jsp/flow/flowEdit";
	private final String definitionkey = "applydesigner";
	
	public FlowAction() {
		super.page_toList = page_toList;
		super.page_toAdd = page_toAdd;
		super.page_toEdit = page_toEdit;
	}
	
	@Override
	public BaseLogic<FlowVo> getLogic() {
		// TODO Auto-generated method stub
		return flowLogic;
	}
	
	/**
	 * 启动设备申请流程
	 * 
	 * @param leave
	 */
	@RequestMapping(value = "start", method = RequestMethod.POST)
	@ResponseBody
	public String start(@ModelAttribute("params") FlowVo bean, HttpServletRequest req) {
		String msg = null;
		Map<String, Object> variables = new HashMap<String, Object>();
		try {
			String applyId = req.getParameter("flow_id");
			bean = this.flowLogic.queryOne(applyId,FlowVo.class,"flow_id");
			variables = ReflectionUtil.getDeclaredAnnotationFieldsName(bean, WorkflowVariable.class);
			TbUserVo user = SessionUserUtil.getUserFromSession();
			ProcessInstance processInstance = WorkflowUtils.startWorkflow(definitionkey, user.getUser_code(), variables);
			bean.setBiz_key(processInstance.getBusinessKey());
			this.flowLogic.updateEntityBizKey(bean);
			Task task = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).active().singleResult();
			/**检查流程处理人设置*/
			TbFlowAssignee assigneeVo = this.flowAssigneeService.queryFlowAssignee(task.getProcessDefinitionId(), task.getTaskDefinitionKey());
			if (null != assigneeVo && !StringUtil.isEmpty(assigneeVo.getAssignee_type()) && !StringUtil.isEmpty(assigneeVo.getAssignee_val())) {
				/**流程处理人指定为员工，直接设置*/
				if(assigneeVo.getAssignee_type().equalsIgnoreCase("4")){
					taskService.addUserIdentityLink(task.getId(), assigneeVo.getAssignee_val(), IdentityLinkType.ASSIGNEE);
				}
				/**流程处理人指定为流程相关，找到相关环节处理人后直接设置*/
				else if(assigneeVo.getAssignee_type().equalsIgnoreCase("5")){
					Task taskHis = taskService.createNativeTaskQuery().sql("select * from act_hi_actinst where PROC_INST_ID_='"+processInstance.getProcessInstanceId()+"' and act_id_='"+assigneeVo.getAssignee_val()+"'").singleResult();
					taskService.addUserIdentityLink(task.getId(), taskHis.getAssignee(), IdentityLinkType.ASSIGNEE);
				}
			}
			task = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).active().singleResult();
			if(null == task.getAssignee() && (null != assigneeVo && null == assigneeVo.getAssignee_val())){
				JSONObject taskObj = new JSONObject();
				taskObj.put("taskId", task.getId());
				taskObj.put("taskName", task.getName());
				if (null != assigneeVo) {
					taskObj.put("assignee_type", assigneeVo.getAssignee_type());
					taskObj.put("assignee_val", assigneeVo.getAssignee_val());
				}
				msg = MsgUtil.getOutMsg(true, "流程已启动，流程ID：" + processInstance.getId(),taskObj);
			}
			else{
				msg = MsgUtil.getOutMsg(true, "流程已启动，流程ID：" + processInstance.getId());
			}
		} catch (ActivitiException e) {
			if (e.getMessage().indexOf("no processes deployed with key") != -1) {
				log.warn("没有部署流程!", e);
				msg = MsgUtil.getOutMsg(false, "没有部署流程，请在[流程管理]->[流程定义及部署管理]页面点击<部署流程>");
			}
			else if (e.getMessage().indexOf("is suspended") != -1) {
				log.warn("流程已挂起!", e);
				msg = MsgUtil.getOutMsg(false, "流程已挂起，请在[流程管理]->[流程部署管理]页面激活流程");
			}else {
				log.error("启动设备申请流程失败：", e);
				msg = MsgUtil.getOutMsg(false, "系统内部错误！"+ StringUtil.trimToEmpty(e.getMessage()));
			}
		} catch (Exception e) {
			log.error("启动设备申请流程失败：", e);
			msg = MsgUtil.getOutMsg(false, "系统内部错误！"+ StringUtil.trimToEmpty(e.getMessage()));
		}
		return msg;
	}
	
	protected void initInsert(FlowVo vo) {
		TbUserVo userVo = SessionUserUtil.getUserFromSession();
		vo.setCreate_user_id(userVo.getUser_id());
	}
	

	@Override
	protected void queryListAfter(List<FlowVo> e) throws Exception {
		
	}

	@Override
	protected void ddlAfter(FlowVo vo) throws Exception {
		
	}
}
