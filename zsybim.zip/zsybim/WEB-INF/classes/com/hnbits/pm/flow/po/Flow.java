package com.hnbits.pm.flow.po;

import com.hnbits.app.workflow.FlowEntity;
/**
 * 
 * <br>
 * <b>功能：</b>FlowEntity<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
public class Flow extends FlowEntity{
		//流程ID	private String flow_id;	//项目ID	private String project_id;	//项目阶段	private String project_phase;	//流程类型	private String project_flow_type;	//流程名称	private String project_flow_name;	//发起时间	private java.util.Date create_time;	//时间节点	private java.util.Date end_time;	//发起人	private String create_user_id;	//责任人	private String duty_user_id;	//重要等级	private String important_grade;	//备注	private String remark;	//流程KEY	private String biz_key;		public String getFlow_id() {	    return this.flow_id;	}	public void setFlow_id(String flow_id) {	    this.flow_id=flow_id;	}	public String getProject_id() {	    return this.project_id;	}	public void setProject_id(String project_id) {	    this.project_id=project_id;	}	public String getProject_phase() {	    return this.project_phase;	}	public void setProject_phase(String project_phase) {	    this.project_phase=project_phase;	}	public String getProject_flow_type() {	    return this.project_flow_type;	}	public void setProject_flow_type(String project_flow_type) {	    this.project_flow_type=project_flow_type;	}	public String getProject_flow_name() {	    return this.project_flow_name;	}	public void setProject_flow_name(String project_flow_name) {	    this.project_flow_name=project_flow_name;	}	public java.util.Date getCreate_time() {	    return this.create_time;	}	public void setCreate_time(java.util.Date create_time) {	    this.create_time=create_time;	}	public java.util.Date getEnd_time() {	    return this.end_time;	}	public void setEnd_time(java.util.Date end_time) {	    this.end_time=end_time;	}	public String getCreate_user_id() {	    return this.create_user_id;	}	public void setCreate_user_id(String create_user_id) {	    this.create_user_id=create_user_id;	}	public String getDuty_user_id() {	    return this.duty_user_id;	}	public void setDuty_user_id(String duty_user_id) {	    this.duty_user_id=duty_user_id;	}	public String getImportant_grade() {	    return this.important_grade;	}	public void setImportant_grade(String important_grade) {	    this.important_grade=important_grade;	}	public String getRemark() {	    return this.remark;	}	public void setRemark(String remark) {	    this.remark=remark;	}	public String getBiz_key() {	    return this.biz_key;	}	public void setBiz_key(String biz_key) {	    this.biz_key=biz_key;	}
	@Override
	public String getPk() {
		// TODO Auto-generated method stub
		return this.flow_id;
	}
}

