package com.hnbits.pm.flow.vo;

import com.hnbits.pm.flow.po.Flow;

/**
 * 
 * <br>
 * <b>功能：</b>FlowVo<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
public class FlowVo extends Flow{
		//发起人	private String create_user_name;	//重要等级	private String important_grade_desc;	//项目阶段名称	private String project_phase_ch;	//项目名称	private String project_name;	//责任人	private String duty_user_name;	//流程类别	private String project_flow_type_desc;		public String getCreate_user_name() {	    return this.create_user_name;	}	public void setCreate_user_name(String create_user_name) {	    this.create_user_name=create_user_name;	}	public String getImportant_grade_desc() {	    return this.important_grade_desc;	}	public void setImportant_grade_desc(String important_grade_desc) {	    this.important_grade_desc=important_grade_desc;	}	public String getProject_phase_ch() {	    return this.project_phase_ch;	}	public void setProject_phase_ch(String project_phase_ch) {	    this.project_phase_ch=project_phase_ch;	}	public String getProject_name() {	    return this.project_name;	}	public void setProject_name(String project_name) {	    this.project_name=project_name;	}	public String getDuty_user_name() {	    return this.duty_user_name;	}	public void setDuty_user_name(String duty_user_name) {	    this.duty_user_name=duty_user_name;	}	public String getProject_flow_type_desc() {	    return this.project_flow_type_desc;	}	public void setProject_flow_type_desc(String project_flow_type_desc) {	    this.project_flow_type_desc=project_flow_type_desc;	}
}
