package com.hnbits.pm.flow.dao;

import com.hnbits.common.annotation.AnnotationDataSource;
import com.hnbits.pm.flow.vo.FlowVo;
import com.hnbits.common.dao.BaseDao;

/**
 * 
 * <br>
 * <b>功能：</b>FlowDao<br>
 * <b>作者：</b>www.hnbits.com<br>
 * <b>日期：</b> Feb 4, 2014 <br>
 * <b>版权所有：<b>版权所有(C) 2014，www.hnbits.com<br>
 */
@AnnotationDataSource(datasource="master",schema="bim")
public interface FlowDao extends BaseDao<FlowVo>{
	
	public int updateByBizKey(FlowVo vo) throws Exception;
}
