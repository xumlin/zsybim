/**
 * 
 */
package com.hnbits.common.tree;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hnbits.util.ReflectionUtil;
import com.hnbits.util.StringUtil;



/**
 * 树形数据结构的实现，主要用于tree的数据构造
 * @author Xiaonian.Yang
 * 
 */
public abstract class BaseTree<T>{
	
	/**
	 * treeid fieldname
	 */
	protected String idField ="id";
	
	/**
	 * 父级id fieldname
	 */
	protected String parentField= null;
	
	/**
	 * 名称 fieldname
	 */
	protected String textField ="text";
	
	protected String iconField = null;
	
	/**
	 * 是否选中 fieldname
	 */
	protected String checkedField= null; 
	
	/**
	 * 状态 fieldname
	 */
	protected String stateField = null;
	
	protected String rootNodeId = null;
	
	/**
	 * 构建tree的二维数据，数据中必须有parentId 的映射
	 */
	protected List<T> dataList;
	
	protected List<String> attributesList;
	
	protected String defaultState = null;
	
	/**
	 * 根节点
	 */
	protected List<T> rootNodeList = new ArrayList<T>();
	
	protected JSONArray tree = new JSONArray();
	
	public BaseTree(){
		
	}
	
	private void buildTree(String rootNodeId){
		this.rootNodeId = rootNodeId;
		initRoot();
		for(T treeNode:rootNodeList){
			tree.add(build(treeNode));
		}
	}
	
	/**
	 * 将普通数据记录集构建成TreeNode数据结构，记录集中需要有明确的父子结构描述，
	 * 可以通过指定idField，parentField，textField，checkedField，stateField 来匹配
	 * 数据记录集中的数据
	 * @param treeNode
	 */
	protected abstract JSONObject build(T treeNode);
	
	protected boolean hasChild(T treeNode){
		if(null != this.parentField){
			for(T o1:dataList){
				Object parentId = ReflectionUtil.getFieldValue(o1, this.parentField);
				if(parentId==null){
					continue;
				}
				Object nodeid = ReflectionUtil.getFieldValue(treeNode, this.idField);
				if(!StringUtil.isEmpty(parentId) && !StringUtil.isEmpty(nodeid) && (parentId.equals(nodeid) || parentId.toString().trim().equals(nodeid.toString().trim()))){
					return true;
				}
			}
		}
		return false;
	}
	
	protected List<T> getChildren(T treeNode){
		List<T> list = new ArrayList<T>();
		if(null != this.parentField){
			for(T o1:dataList){
				Object v1 = ReflectionUtil.getFieldValue(treeNode, this.idField);
				Object v2 = ReflectionUtil.getFieldValue(o1, this.parentField);
				if(!StringUtil.isEmpty(v1) && !StringUtil.isEmpty(v2) && (v1.equals(v2) || v1.toString().trim().equals(v2.toString().trim()))){
					list.add(o1);
				}
			}
		}
		return list;
	}
	
	protected void initRoot(){
		for(T o1:dataList){
			Object opf = ReflectionUtil.getFieldValue(o1, this.parentField);
			if(StringUtil.isEmpty(opf) || opf.toString().trim().equals("0") || (!StringUtil.isEmpty(opf) && opf.toString().trim().equals(rootNodeId))){
				this.rootNodeList.add(o1);
			}
		}
	}
	
	/**
	 * 生成treeNode的json格式数据
	 * @return
	 */
	public String buildJson(String ...rootNodeId){
		try {
			if(null != rootNodeId && rootNodeId.length > 0)
				this.rootNodeId = rootNodeId[0];
			buildTree(this.rootNodeId);
			return tree.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	public String buildJson(String rootNodeId){
		try {
			buildTree(rootNodeId);
			return tree.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	

	/**
	 * get checkedField
	 * @return
	 */
	public String getCheckedField() {
		return checkedField;
	}

	/**
	 * set checkedField
	 * @param checkedField
	 */
	public void setCheckedField(String checkedField) {
		this.checkedField = checkedField;
	}

	/**
	 * get dataList
	 * @return
	 */
	public List getDataList() {
		return dataList;
	}

	/**
	 * set dataList
	 * @param dataList
	 */
	public void setDataList(List dataList) {
		this.dataList = dataList;
	}

	/**
	 * get idField
	 * @return
	 */
	public String getIdField() {
		return idField;
	}
	

	public String getRootNodeId() {
		return rootNodeId;
	}

	public void setRootNodeId(String rootNodeId) {
		this.rootNodeId = rootNodeId;
	}

	/**
	 * set idField
	 * @param idField
	 */
	public void setIdField(String idField) {
		this.idField = idField;
	}

	/**
	 * get parentField
	 * @return
	 */
	public String getParentField() {
		return parentField;
	}

	/**
	 * set parentField
	 * @param parentField
	 */
	public void setParentField(String parentField) {
		this.parentField = parentField;
	}
	
	/**
	 * get stateField
	 * @return
	 */
	public String getStateField() {
		return stateField;
	}

	/**
	 * set stateField
	 * @param stateField
	 */
	public void setStateField(String stateField) {
		this.stateField = stateField;
	}

	/**
	 * get textField
	 * @return
	 */
	public String getTextField() {
		return textField;
	}

	/**
	 * set textField
	 * @param textField
	 */
	public void setTextField(String textField) {
		this.textField = textField;
	}
	
	public List<String> getAttributesList() {
		return attributesList;
	}

	public void setAttributesList(List<String> attributesList) {
		this.attributesList = attributesList;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	}
	
}
