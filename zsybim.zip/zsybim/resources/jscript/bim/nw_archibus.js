//var config = "width=1280,height=768,left=" + screen.availWidth + ",top=0,resizable=yes,scrollbars=no";
var config = "width=1280,height=768,left=0,top=0,resizable=yes,scrollbars=no";

function showUnityDefault() {
    var a = window.open("", "unity_window", config);
    if (a.location == "about:blank") a.location = "/jsp/UnityViewer.html";
}

function showDwfDefault() {
	var a = window.open("", "dwfWindow", config);
	if (a.location == "about:blank") a.location = "/jsp/DwfView.html";
}

var errorTimes = 0;
function ShowArchibus(d, className) {
    $('.' +className).removeClass(className).addClass('unselect');
    var e = $(d).attr('data');
    var f = "/archibus/schema/" + e;
    var g = $.param({
        'username': $.cookies.get("afm_username_per_computer"),
        'projectId': $.cookies.get("afm_project_id_per_computer")
    });
    $.ajax({
        url: f,
        data: g,
        type: 'POST',
        cache: false,
        beforeSend: function() {
            $("#Div").block({
                message: null
            });
        },
        error: function(a, b, c) {
            //console.log(a);
            errorTimes++;
            if (errorTimes <= 2 && a.status == "500")
            	ShowArchibus(d);
            else alert('系统发生错误，请重新读取页面！');
        },
        success: function() {
            $('#convas').attr('src', f);
            $(d).removeClass('unselect').addClass(className);
        },
        complete: function(a) {
            $("#Div").unblock();
        }
    });
}

function ShowArchibusPage(d) {
    $('.left_focus').removeClass('left_focus');
    var e = "/archibus/schema/" + d;
    var f = $.param({
        'username': $.cookies.get("afm_username_per_computer"),
        'projectId': $.cookies.get("afm_project_id_per_computer")
    });
    $.ajax({
        url: e,
        data: f,
        type: 'POST',
        cache: false,
        beforeSend: function() {
            $("#Div").block({
                message: null
            });
            //showNwdDefault();
        },
        error: function(a, b, c) {
            //if (this.console) console.log(c);
            errorTimes++;
            if (errorTimes <= 2 && a.status == "500")
            	ShowArchibusPage(d);
            else alert('系统发生错误，请重新读取页面！');
        },
        success: function() {
            $('#convas').attr('src', e);
        },
        complete: function(a) {
            $("#Div").unblock();
        }
    });
}

function openArchibus(d) {
    var e = "/archibus/schema/" + d;
    var f = $.param({
        'username': $.cookies.get("afm_username_per_computer"),
        'projectId': $.cookies.get("afm_project_id_per_computer")
    });
    $.ajax({
        url: e,
        data: f,
        type: 'POST',
        cache: false,
        beforeSend: function() {
            $("#Div").block({
                message: null
            });
        },
        error: function(a, b, c) {
            if (this.console) console.log(c);
            alert('系统发生错误，请重新读取页面！');
        },
        success: function() {
            window.open(e);
        },
        complete: function(a) {
            $("#Div").unblock();
        }
    });
}

function backLogin() {
    var a = $.cookies.get("afm_project_id_per_computer");
    if (a == null) {
        var b = new Date();
        b.setTime(b.getTime() + (60 * 60 * 1000));
        $.cookies.set("afm_project_id_per_computer", "delta", {
            path: '/',
            expires: b
        });
        $.cookies.set("afm_username_per_computer", 'afm', {
            path: '/',
            expires: b
        });
        a = $.cookies.get("afm_project_id_per_computer");
    }
}

function setLogin(a, b, c) {
    var d = new Date();
    d.setTime(d.getTime() + (60 * 60 * 1000));
    $.cookies.set("afm_project_id_per_computer", a, {
        path: '/',
        expires: d
    });
    $.cookies.set("afm_username_per_computer", b, {
        path: '/',
        expires: d
    });
    $.cookies.set("platform", c, { path: '/', expires: d });
}

function logoutArchibus() {
    var b = "/archibus/schema/ab-logout.axvw";
    var c = $.param({
        'username': $.cookies.get("afm_username_per_computer"),
        'projectId': $.cookies.get("afm_project_id_per_computer")
    });
    var url = 'login' + $.cookies.get("platform") + '.html';
    $.ajax({
        url: b,
        data: c,
        type: 'POST',
        cache: false,
        beforeSend: function() {
            $.blockUI({
                message: null
            });
        },
        success: function() {
            window.open(b, "archibus");
        },
        complete: function(a) {
            $.cookies.del("afm_username_per_computer");
            $.cookies.del("afm_project_id_per_computer");
            location.href = url;
            $.unblockUI();
        }
    });
}

function ShowOtherPage(a, className) {
    //$('.subgroup').hide();
    $('.' + className).removeClass(className).addClass('unselect');
    var b = $(a).attr('data');
    $('#convas').attr('src', b);
    $(a).removeClass('unselect').addClass(className);
}

function ShowOtherMainPage(a, className) {
    $('.subgroup').hide();
    $('.' + className).removeClass(className);
    var b = $(a).attr('data');
    $('#convas').attr('src', b);
    $(a).addClass(className);
}

function openPage(a) {
    var b = $(a).attr('page');
    window.open(b);
}

function setDropWidth() {
    $("#drag").hover(function() {
        $(this).css('cursor', 'e-resize');
    }, function() {
        $(this).css('cursor', 'default');
    });
    $('#drag').on('mousedown', function(e) {
        $(document).on('mouseup', function(e) {
            $(document).off('mouseup').off('mousemove');
        });
        $(document).on('mousemove', function(a) {
            if (a.pageX <= 220 && a.pageX >= 50) {
                $(".div_left").css({
                    width: a.pageX
                });
                $("#logo").css({
                    width: a.pageX - 10
                });
                $(".header_menu").css({
                    width: a.pageX - 10
                });
                $(".submenu").css({
                    width: a.pageX - 20
                });
                $("#Div").css({
                    left: a.pageX,
                    width: screen.availWidth - a.pageX - 40
                });
            }
        });
    });
}

function setWindowHeight() {
	var i = $(".HMenu").length - 1;
	var w = $(".header").width() - $("#logo").width() - (85 * i) - 35 * 3 - 50;
	$("#else").width(w);
	var h = $(window).innerHeight() - $(".top").height() - $("#logo").height() - 20;
	console.log($('.VMenu:eq(1)').offset().top + $('.VMenu:eq(1)').height());
	h2 = $('.VMenu:eq(1)').offset().top + $('.VMenu:eq(1)').height();
	if (h2 > h) h = h2;
	$("#content").height(h);
    //$('.div_left').height($(window).height() - 10);
    //$("#Div").width(screen.availWidth - $(".div_left").width() - 40);
    //$("#Div").height($(".header_login").height() + $(".header_login").offset().top);
}

function getEventData() {
	getEventCount();
	getEventList();
}

function getEventList() {
	$.ajax({
		type: "POST",
		url: "Event",
		data: "mode=list",
		success: function (data) {
//			var objJSON = eval("(" + data + ")");
//			$("#eventList tbody tr").remove();
//			var tbody = $("#eventList tbody"); var emergency, tagTD;
//			for (var row in objJSON) {
//				var objTR = document.createElement("tr");
//				$(objTR).bind('click', eventClick);
//				$(objTR).attr('data-std', objJSON[row]['eqstd']);
//				emergency = objJSON[row]['emer'];
//				tagTD = "<td class='level" + emergency + "'>";
//				$(objTR).append($(tagTD).text(emergency));
//				$(objTR).append($(tagTD).text(objJSON[row]['date']));
//				$(objTR).append($(tagTD).text(objJSON[row]['status']));
//				$(objTR).append($(tagTD).text(objJSON[row]['location']));
//				$(objTR).append($(tagTD).text(objJSON[row]['id']));
//				$(objTR).append($(tagTD).text(objJSON[row]['desc']));
//				$(tbody).append(objTR);
//			}
		},
		error: function(xhr) {
			if (xhr.status == 501) alert('参数错误，请通知系统维护人员！');
			else alert('无法取得事件列表，请稍后再试！');
		}
	});
}

function getEventCount() {
	$.ajax({
		type: "POST",
		url: "Event",
		data: "mode=count",
		success: function (data) {
//			var objJSON = eval("(" + data + ")");
//			var rowData, iTotal = 0;
//			for (var status in objJSON) {
//				rowData = $(".confirm"); iTotal = 0;
//				if (status == "0") rowData = $(".unconfirm");
//				for (var col in objJSON[status]) {
//					$(rowData).find("td:eq("+col+")").text(objJSON[status][col]);
//					iTotal += parseInt(objJSON[status][col]);
//				}
//				$(rowData).find("td:eq(6)").text(iTotal);
//			}
		},
		error: function(xhr) {
			if (xhr.status == 501) alert('参数错误，请通知系统维护人员！');
			else alert('无法取得事件计数，请稍后再试！');
		}
	});
}

function eventClick() {
	var row = $(this);
	console.log(row);
	var eqId = $(row).find("td:eq(4)").text();
	$("#eventHandle .hintData").text(eqId + " : " + $(row).find("td:eq(5)").text() + " / " +$(row).attr('data-std'));

	var url = 'gs-emergency-event-s.axvw?eq=' + eqId;
	window.top.ShowArchibusPage(url);
}

function setRandomEvent() {
	$.ajax({
		type: "POST",
		url: "randomEvent",
		//data: "mode=count",
		success: function (data) {
			//console.log(data);
			getEventData();
		},
		error: function(xhr) {
			if (xhr.status == 501) alert('参数错误，请通知系统维护人员！');
			else alert('无法产生乱数事件，请稍后再试！');
		}
	});
}