/**
 * 2014-11-13 By Oscar 整理 Autodesk Viewer and Data API 可用之函式
 */

var viewer3D;
var documentId;
var auth;
//Viewer Document
var currentViewerDoc;
//Geometry nodes
var geometryItems;
var geometryItems_children;
//For navigation between nodes
var selectedModelListIndex = 0;
var currNodes = [];
var currNode = null;
var level = 0;
var lastTime = 0, diffTime = 0;

function InitializeViewer() {
	//get the token.
	var token = $.cookies.get("token");
	UpdateCommandLine(token);

	//set the token
	xmlhttp = new XMLHttpRequest();

	xmlhttp.open('POST', 'https://developer.api.autodesk.com/utility/v1/settoken', false);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.onreadystatechange = function() { UpdateCommandLine("set token Successful "); };
	xmlhttp.onerror = function() { UpdateCommandLine('set token error'); };
	xmlhttp.withCredentials = true;
	xmlhttp.send("access-token=" + token);

	var options = {};
	options.env = "AutodeskProduction";
	options.accessToken = token;

	geometryItems = null;
	geometryItems_children = null;

	currNodes = [];
	currNode = null;
	level = 0;
	documentId = "urn:" + $("#model").val();

	// For navigation between nodes
	selectedModelListIndex = -1;
	var viewerContainer = document.getElementById('viewer');

	Autodesk.Viewing.Initializer(options, function () {
		lastTime = $.now();
		UpdateCommandLine('lastTime: ' + lastTime);
		viewer3D = new Autodesk.Viewing.Private.GuiViewer3D(viewerContainer, {});

		viewer3D.initialize();
		//load the document
		Autodesk.Viewing.Document.load(documentId, onSuccessDocumentLoadCB, onErrorDocumentLoadCB);

		viewer3D.setPropertiesOnSelect(true);
		viewer3D.setGhosting(true);
	});
}

//Document successfully loaded 
function onSuccessDocumentLoadCB(viewerDocument) {
	//store the varibale in currentViewerDoc.
	currentViewerDoc = viewerDocument;

	//get the root.
	var rootItem = viewerDocument.getRootItem();

	//store in globle variable
	geometryItems = Autodesk.Viewing.Document.getSubItemsWithProperties(rootItem, { 'type': 'geometry', 'role': '3d' }, true);

	//console.log(rootItem);
	if (geometryItems.length > 0) {
		var item3d = viewerDocument.getViewablePath(geometryItems[0]);

		//load the geometry in the viewer.
		viewer3D.addEventListener(Autodesk.Viewing.GEOMETRY_LOADED_EVENT, geometryLoadedEventCB);
		viewer3D.addEventListener(Autodesk.Viewing.SELECTION_CHANGED_EVENT, onSelectedCallback);
		viewer3D.load(item3d);
		level = 0;

		// Add the 3d geometry items to the list
		//$("#ModelList").empty();

		//$("#NavigateForwardBtn").prop('disabled', false);
		//$("#NavigateBackBtn").prop('disabled', true);

		//var itemList = htmlDoc.getElementById('ModelList');
		//for (var i = 0; i < geometryItems.length; i++) {
		//	itemList.add(new Option(geometryItems[i].name, geometryItems[i]));
		//}
	}
}

//Some error during document load
function onErrorDocumentLoadCB(errorMsg, errorCode) {
	//$('#tree_container').empty();
	UpdateCommandLine("Unable to load the document : " + documentId + errorMsg);
}

//Get the object tree and load the select elements for navigation
function getObjectTreeCB(result) {
	if (level == 0) {
		geometryItems_children = result.children;
	} else {
		geometryItems_children = result.children;
		for (var i = 0; i < geometryItems_children.length; i++) {
			currNodes.push(geometryItems_children[i]);
		}
	}
}

function geometryLoadedEventCB(event) {
	UpdateCommandLine("Geometry loaded event");
	viewer3D.getObjectTree(getObjectTreeCB);
	viewer3D.removeEventListener(Autodesk.Viewing.GEOMETRY_LOADED_EVENT, geometryLoadedEventCB);
	viewer3D.showAll();
	viewer3D.fitToView();
	diffTime = $.now() - lastTime;
	UpdateCommandLine("show all. Total time(ms): " + diffTime);
	$.unblockUI();
}

function UpdateCommandLine(text) {
	var itemList = $('#OutputMessages option').eq(0);
	itemList.before($("<option></option>").val(text).html(text));
}

//call back function of search.
function onSearchResultsReturned(idArray) {
	//for testing isoloate all the ids
	viewer3D.isolateById(idArray);
	viewer3D.fitToView();
	//viewer3D.select(idArray);

	//update the commnadline window.
	if (idArray.length == 0) {
		UpdateCommandLine("No objects found in Search ");
		return;
	}

	UpdateCommandLine(idArray.length + " items found in the Search -------");

	diffTime = $.now() - lastTime;
	UpdateCommandLine('Search Time(ms): ' + diffTime);
	$.unblockUI();
}

//this function is called from Search button click
function Search_onclick() {
	$.blockUI({ message: null });
	var Search = $("#txtSearch").val();
	lastTime = $.now();
	viewer3D.search(Search, onSearchResultsReturned);
}

function onSelectedCallback(event) {
	UpdateCommandLine('click ' + event.dbIdArray.length + ' items.');
	if (event.dbIdArray.length > 0) {
		viewer3D.getProperties(event.dbIdArray[0], function(props) {
			console.log(event);
			for (var i = 0; i < props.properties.length; i ++)
				if (props.properties[i].displayName.indexOf('_id') > 0)
					UpdateCommandLine(props.properties[i].displayName + " = " + props.properties[i].displayValue);
		});
		viewer3D.select(event.dbIdArray[0]);
		//viewer3D.fitToView();
		setTimeout(zoomin_onclick, 10000);
		//setTimeout(zoomin_onclick, 20000);
	}
}

//call back function of select item.
function onSelectResultsReturned(idArray) {
	//update the commnadline window.
	if (idArray.length == 0) {
		UpdateCommandLine("No objects found in Select ");
		return;
	}

	UpdateCommandLine(idArray.length + " items found in the Select -------");

	//viewer3D.isolateById(idArray[0]);
	viewer3D.select(idArray);
	//viewer3D.fitToView();

	diffTime = $.now() - lastTime;
	UpdateCommandLine('Select Time(ms): ' + diffTime);
	$.unblockUI();
}

function SearchItem() {
	$.blockUI({ message: null });
	var Search = $("#txtSelect").val();
	lastTime = $.now();
	viewer3D.search(Search, onSelectResultsReturned);
}

//timer end function. used in 
function continueExecution() {
	//viewer3D.impl.controls.autoMove(automoveType, false);
	var orbit = viewer3D.toolController.getTool("orbit");
	orbit.autoMove(automoveType, false);
}

//zoom-in
function zoomin_onclick() {
	viewer3D.canvas.focus();
	automoveType = 5;
	viewer3D.setZoomTowardsPivot(true);
	UpdateCommandLine('ZoomIn');

	var orbit = viewer3D.toolController.getTool("orbit");
	orbit.autoMove(automoveType, true);
	setTimeout(continueExecution, 250);
}
