/**
 * 
 */
String.format = function () {
    var s = arguments[0];
    if (s == null) return "";
    for (var i = 0; i < arguments.length - 1; i++) {
        var reg = getStringFormatPlaceHolderRegEx(i);
        s = s.replace(reg, (arguments[i + 1] == null ? "" : arguments[i + 1]));
    }
    return cleanStringFormatResult(s);
}

function getStringFormatPlaceHolderRegEx(placeHolderIndex) {
    return new RegExp('({)?\\{' + placeHolderIndex + '\\}(?!})', 'gm');
}

function cleanStringFormatResult(txt) {
    if (txt == null) return "";
    return txt.replace(getStringFormatPlaceHolderRegEx("\\d+"), "");
}

function toggleSubMenu(d) {
	var subDisplay = $(d).next('.subgroup').css('display');
	$('.subgroup').hide();
	if (subDisplay == "none") $(d).next().toggle();
	$('.selected').removeClass('selected');
	//$(d).addClass('focus_menu');
}

function userFunctionLog(d) {
	$.ajax({
		type : "GET",
		//contentType: 'application/x-www-form-urlencoded; charset-UTF-8',
		url : "userLog",
		data : "function_name=" + encodeURI($(d).text()),
		success : function(data) {
			//console.log(data);
		}
	});
}

function getUserLog(page) {
	console.log(page);
	$.ajax({
		type: 'POST',
		url: "userLog",
		data: 'page=' + page + "&pageSize=20",
		success : function(data) {
			//console.log(data);
			var aryData = data.split("|");
			var iTotalRow = parseInt(aryData[0]);
			var jsonData = eval(aryData[1]);
			var str = "<table class='log'>\n";
			str += "<tr class='header'><td>序号</td><td>登入帐号</td><td>执行功能</td><td>执行时间</td></tr>\n";
			str += showLogList(jsonData);
			str += "</table>";
			$("#log").html(str);
			$("#page").html(showPageData(iTotalRow, page, 20));
			$("select").change(function() { getUserLog($(this).val()); });
		}
	});
}

function showLogList(jsonLog) {
	var strPattern = "<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>";
	var strReturn = "";
	for(var i = 0; i < jsonLog.length; i++) {
		var obj = jsonLog[i];
		var strRow = String.format(strPattern, obj.id, obj.user, obj.function, obj.time);
		strReturn += strRow + "\n";
	}
	return strReturn;
}

function showPageData(records, page, pageSize) {
	if (pageSize == undefined) pageSize = 50;
	var pages = Math.ceil(records / pageSize);
	var strPage = "共{0}页/目前第{1}页，切换至 {2} 页";
	var strSelect = "<select id='pages'>";
	for (var i = 1; i <= pages; i++) {
		if (i == page) selected = " selected='selected'"; else selected = "";
		strSelect += String.format("<option value='{0}'{2}>{1}", i, i, selected);
	}
	strSelect += "</select>";
	strPage = String.format(strPage, pages, page, strSelect);
	return strPage;
}
