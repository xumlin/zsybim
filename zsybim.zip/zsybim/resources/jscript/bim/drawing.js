/**
 * 2013-12-26 Wrote By Oscar Fang
 * 提供第二视屏操作的 JavaScript
 * 2013-12-31 增加讀取圖檔以及亮顯設備或房間之函式
 */
function resetWindow() {
	window.moveTo(screen.availWidth * -1, 0);
	var h = $(window).height() - 80;
	$(".framediv").height(h / 2);
}

function toggleFrameWin() {
	var h = $(window).height() - 80;
	$(".framediv").hide();
	var objParent = $(this).parent();
	//if(console) console.log(h);
	if ($(objParent).height() > (h / 2)) {
		$(objParent).height(h / 2);
		$(".framediv").show();
		$(this).text('全屏');
	} else {
		$(objParent).height(h).show();
		$(this).text('半屏');
	}
}

function showPartDrawing(dataPart) {
	if (dataPart == undefined || dataPart == "") dataPart = 'E';
	$.ajax({
		type: "POST",
		url: "PartDefault",
		data: "mode=part&part=" + dataPart,
		success: function (data) {
			var objJSON = eval("(" + data + ")");
			if (this.console) { console.log(data); console.log(objJSON['floor']); }
			showFloorDrawing(objJSON['floor']);
		},
		error: function(xhr) {
			if (xhr.status == 501) alert('参数错误，请通知系统维护人员！');
			else alert('主机发生错误，请连络系统管理人员！');
		}
	});
}

function showEquipment(dataEq, dataStd) {
	$.ajax({
		type: "POST",
		url: "PartDefault",
		data: "mode=eq&eq=" + dataEq,
		success: function (data) {
			var objJSON = eval("(" + data + ")");
			//if (this.console) { console.log(data); console.log(objJSON['floor']); }
			showFloorDrawing(objJSON['floor']);
			$("#naviswork")[0].contentWindow.highlight(dataEq, dataStd);
			$("#archibus")[0].contentWindow.highlightRoom(objJSON['room']);
		},
		error: function(xhr) {
			if (xhr.status == 501) alert('参数错误，请通知系统维护人员！');
			else alert('主机发生错误，请连络系统管理人员！');
		}
	});
}

function showFloorDrawing(floor, type) {
	$("#naviswork")[0].contentWindow.loadFloor('HKHCZ', floor, type);
	$("#archibus")[0].contentWindow.loadDrawing('HKHCZ', floor);
}

function highlightRoom(room) {
	$("#naviswork")[0].contentWindow.highlight(room);
	$("#archibus")[0].contentWindow.highlightRoom(room);
}

function showEqValue(eqList) {
	$("#naviswork")[0].contentWindow.setLabelIds(eqList);
}
