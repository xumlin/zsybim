/**
 * Created by CherryDream on 2016/9/1.
 */
(function ($) {
    $.fn.bootstrapCombotree = function (options, param) {
        if(typeof options === 'string')
        {
            return bootstrapCombotree.prototype[options](this, param);
        }
        options = options || {};
        this.each(function () {
            // var Value = new Array();

            var state = $.data(this, 'bootstrapCombotree');
            if(state)
            {
                $.extend(state.options, options);
            }
            else
            {
                $.data(this, 'bootstrapCombotree', {
                    options : $.extend({}, $.fn.bootstrapCombotree.defaults, options)
                });
            }
            // $.data(this, "text", Text);
            // $.data(this, "value", value);
            var btComboTree = new bootstrapCombotree().init(this);
        })
    };
    var bootstrapCombotree = function(){
    	this.cascade = false;
    	this.multiple = false,
        this.Text = new Array();
        this.value = new Array();
        this.$Tree = undefined;
        this.$Button = undefined;
        this.$hidden = undefined;
        this.$text = undefined;
        this.init = function (target) {
            var options = $.data(target, "bootstrapCombotree").options;
            options.defaultLable = options.defaultLable?options.defaultLable:"&nbsp;";
            $(target).empty();
            //写html标签
            if (options.width == undefined) {
            	options.width = 160;
            }                
                target.innerHTML = '<div class="input-group">'
                	+ '<input type="text" readonly class="form-control" style="width: ' + (options.width-37) + 'px;"/>'
                	+ '<div class="input-group-btn" style="width: ' + options.width + 'px;">'
                    + '<button type="button" class="btn btn-default dropdown-toggle"  data-toggle="dropdown" title=' + options.defaultLable + '>'
                    + options.defaultLable + '<span class="caret"></span>'
                    + '</button>'
                    + '<input type="hidden" name="' + options.name + '"/> '
                    + '<div class="dropdown-menu" style="width: ' + options.width + 'px;left:-' + (options.width-37) + 'px;"></div>'
                    + '</div>'
	                + '</div>';

             this.cascade = options.cascade;
            this.multiple = options.multiple;
            this.showTextOnButton = false;
            this.$Tree = $(target).find(".dropdown-menu");//Tree对象
            this.$Button = $(target).find("button");//button对象
            this.$hidden = $(target).find("input[type='hidden']");//隐藏域
            this.$text = $(target).find("input[type='text']");//选择内容显示区
            //渲染bootstrap-treeview
            var _this = this;
            var showCheckbox = (this.multiple)?true:false;
            this.$Tree.treeview({
                data: options.data,
                showIcon: options.showIcon,
                showCheckbox: showCheckbox,
                onNodeChecked: function (event, node) {
                    options.onBeforeCheck(node);
                    if($(target).data("value") != undefined)
                    {
                        this.Text = $(target).data("Text");
                        this.value = $(target).data("value");
                    }

                    if(_this.$Button[0].innerText == options.defaultLable)
                    {
                        _this.$Button[0].innerText = '';
                    }
                    _this.setCheck(node) ;
                    if(options.multiple && options.cascade)
                    _this.setCheckparent(node);
                    if (_this.Text.length <= options.maxItemsDisplay) {
                    	if(options.showTextOnButton){
                    		_this.$Button[0].innerHTML = _this.Text + '<span class="caret"></span>';
                    		_this.$Button.attr("title", _this.Text);
                    	}
                        _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                    }
                    else {
                    	if(options.showTextOnButton){
                    		_this.$Button[0].innerHTML = _this.Text.length + '项被选中  <span class="caret"></span>';
                    		_this.$Button.attr("title", _this.Text.length + '项被选中');
                    	}
                        _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                    }
                    _this.$hidden.val(_this.value);
                    if (options.onCheck != undefined) {
                        options.onCheck(node);
                    }
                },
                onNodeUnchecked: function (event, node) {
                    options.onBeforeUnCheck(node);
                    if($(target).data("value") != undefined)
                    {
                        this.Text = $(target).data("Text");
                        this.value = $(target).data("value");
                    }
                    _this.setUnCheck(node);
                    if(options.multiple && options.cascade)
                    _this.setunCheckparent(node);
                    if (_this.Text.length == 0) {
                    	if(options.showTextOnButton){
                    		_this.$Button[0].innerHTML = options.defaultLable + '<span class="caret"></span>';
                    		_this.$Button.attr("title", options.defaultLable);
                    	}
                        _this.$text.val('').attr("title", '');
                    }
                    else {
                        if (_this.Text.length <= options.maxItemsDisplay) {
                        	if(options.showTextOnButton){
                        		_this.$Button[0].innerHTML = _this.Text + '<span class="caret"></span>';
                        		_this.$Button.attr("title", _this.Text);
                        	}
                            _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                        }
                        else {
                        	if(options.showTextOnButton){
                        		_this.$Button[0].innerHTML = _this.Text.length + '项被选中 <span class="caret"></span>';
                        		_this.$Button.attr("title", _this.Text.length + '项被选中');
                        	}
                            _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                        }
                    }
                    _this.$hidden.val(_this.value);
                    if (options.onUnCheck != null) {
                        options.onUnCheck(node);
                    }
                },
                onNodeSelected : function (event, node) {
                    if(options.selectToCheck)
                    {
                        if($(target).data("value") != undefined)
                        {
                            this.Text = $(target).data("Text");
                            this.value = $(target).data("value");
                        }
                        if(node.state.checked)
                        {
                            options.onBeforeUnCheck(node);
                            _this.setUnCheck(node);
                            if(options.multiple && options.cascade)
                            _this.setunCheckparent(node);
                            if (_this.Text.length == 0) {
                            	if(options.showTextOnButton){
                            		_this.$Button[0].innerHTML = options.defaultLable + '<span class="caret"></span>';
                            		_this.$Button.attr("title", options.defaultLable);
                            	}
                                _this.$text.val('').attr("title", '');
                            }
                            else {
                                if (_this.Text.length <= options.maxItemsDisplay) {
                                	if(options.showTextOnButton){
                                		_this.$Button[0].innerHTML = _this.Text + '<span class="caret"></span>';
                                		_this.$Button.attr("title", _this.Text);
                                	}
                                    _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                                }
                                else {
                                	if(options.showTextOnButton){
                                		_this.$Button[0].innerHTML = _this.Text.length + '项被选中 <span class="caret"></span>';
                                		_this.$Button.attr("title", _this.Text.length + '项被选中');
                                	}
                                    _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                                }
                            }
                            _this.$hidden.val(_this.value);
                            if (options.onUnCheck != null) {
                                options.onUnCheck(node);
                            }
                        }
                        else
                        {
                            options.onBeforeCheck(node);
                            if(_this.$Button[0].innerText == options.defaultLable)
                            {
                                _this.$Button[0].innerText = '';
                            }
                            _this.setCheck(node) ;
                            if(options.multiple && options.cascade)
                            _this.setCheckparent(node);
                            if (_this.Text.length <= options.maxItemsDisplay) {
                            	if(options.showTextOnButton){
                            		_this.$Button[0].innerHTML = _this.Text + '<span class="caret"></span>';
                            		_this.$Button.attr("title", _this.Text);
                            	}
                                _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                            }
                            else {
                            	if(options.showTextOnButton){
                            		_this.$Button[0].innerHTML = _this.Text.length + '项被选中  <span class="caret"></span>';
                            		_this.$Button.attr("title", _this.Text.length + '项被选中');
                            	}
                                _this.$text.val(_this.Text.join()).attr("title", _this.Text.join());
                            }
                            _this.$hidden.val(_this.value);
                            if (options.onCheck != undefined) {
                                options.onCheck(node);
                            }
                        }
                    }
                }
            });
            var dropclick = false;
            // 2016-08-24 此时返回false可以阻止下拉框被隐藏
            // 2016=08-25 此问题解决
            $(target).on('hide.bs.dropdown', function (e) {
                if(dropclick)
                {
                    dropclick = false;
                    return false;
                }
                else
                {
                    return true;
                }
            });
            this.$Tree.on('click', function () {
                dropclick = true;
            });
            $.data(target, "Text", this.Text);
            $.data(target, "value", this.value);
        };
        this.setCheck  = function (node) {
        	if(this.multiple==false)
        	this.$Tree.treeview('uncheckNode', [this.$Tree.treeview('getChecked'), { silent: true}]);
            this.$Tree.treeview('checkNode', [this.$Tree.treeview('getNode', [ node.nodeId, { ignoreCase: true, exactMatch: false }]), { silent: true}]);
            if(node == undefined)
            {
                return;
            }
            else
            {
            	if($.inArray(node.id, this.value) < 0)
            	{
            		this.value.push(node.id);
            		this.Text.push(node.text);
            	}
                if(node.nodes == undefined)
                {
                }
                else if(this.multiple && this.cascade)
                {
                    for(var i = 0; i < node.nodes.length; i++)
                    {
                        this.setCheck(node.nodes[i]);
                    }
                }
            }

        	if(this.multiple==false){
                this.value=[node.id];
                this.Text=[node.text];
        	}
        };
        this.setCheckparent = function (node) {
        	if($.inArray(node.id, this.value) < 0)
        	{
        		this.value.push(node.id);
        		this.Text.push(node.text);
        	}
            if(node.parentId == undefined)
            {
                return;
            }
            var pNode = this.$Tree.treeview('getNode', [ node.parentId, { ignoreCase: true, exactMatch: false } ]);
            this.$Tree.treeview('checkNode', [ pNode, { silent: true}]);
            this.setCheckparent(pNode);
        };
        this.setUnCheck = function (node) {
            this.$Tree.treeview('uncheckNode', [ this.$Tree.treeview('searchById', [ node.id, { ignoreCase: true, exactMatch: false } ]), { silent: true}]);
            if(node == undefined)
            {
                return;
            }
            else
            {
            	for(var i = 0; i < this.value.length; i++)
            	{
            		if (this.value[i] == node.id) {
            			this.Text.splice(i, 1);
            			this.value.splice(i, 1);
            		}
            	}
                if(node.nodes == undefined)
                {
                }
                else if(this.multiple && this.cascade)
                {
                    for(var i = 0; i < node.nodes.length; i++)
                    {
                        this.setUnCheck(node.nodes[i]);
                    }
                }
            }
        };
        this.setunCheckparent = function (node) {
        	for(var i = 0; i < this.value.length; i++)
        	{
        		if (this.value[i] == node.id) {
        			this.value.splice(i, 1);
        			this.Text.splice(i, 1);
        		}
        	}
            if (node.parentId == undefined) {
                return;
            }
            var pNode = this.$Tree.treeview('getNode', [node.parentId, {ignoreCase: true, exactMatch: false}]);
            var flag = true;
            for(var i = 0; i < pNode.nodes.length; i++)
            {
                if(pNode.nodes[i].state.checked)
                {
                    flag = false;
                    break;
                }
            }
            if(flag)
            {
                this.$Tree.treeview('uncheckNode', [ pNode, { silent: true}]);
                this.setunCheckparent(pNode);
            }
            else
            {
                return;
            }
        };
    }
    //默认值
    $.fn.bootstrapCombotree.defaults = {
        	multiple : false,
        	cascade : true,
        defaultLable : '请选择列表',//默认按钮上的文本
        showIcon: true,//显示图标
        maxItemsDisplay : 3,//按钮上最多显示多少项，如果超出这个数目，将会以‘XX项已被选中代替’
        selectToCheck : true,
        onCheck : function (node) {//树形菜单被选中是 触发事件

        },
        onBeforeCheck : function (node) {
            return true;
        },
        onBeforeUnCheck : function (node) {
            return true;
        },
        onUnCheck : function (node) {

        }
    };

    /**
     * 获取选中的节点值
     * @param target
     * @returns {*}
     */
    bootstrapCombotree.prototype.getValue = function (target) {
        return $(target).data("value");
    }

    /**
     * 为组件赋值
     * @param target
     * @param param
     */
    bootstrapCombotree.prototype.setValue = function (target, param) {
        var value = $(target).data("value");
        var text = $(target).data("Text");
        var opt =  $(target).data("bootstrapCombotree").options;
        var Tree = $(target).find(".dropdown-menu");//Tree对象
        var Button = $(target).find("button");//button对象
        var hidden = $(target).find("input[type='hidden']");//隐藏域
        var Text = $(target).find("input[type='text']");//选择内容显示区
        var arr = param.split(",");
        if(!this.multiple)arr = [arr[0]];
        value.splice(0);
        text.splice(0);
        Tree.treeview("uncheckAll", { silent: true });//全部不选
        for(var i = 0; i < arr.length; i++)
        {
            var node = Tree.treeview('searchById', [ arr[i], { ignoreCase: true, exactMatch: false }]);
            if(node !=undefined && node.length != 0)
            {
            	value.push(arr[i]);
            	text.push(node[0].text);
                if(!node.nodes)
                {
                }
                else
                {
                //    continue;
                }
                Tree.treeview('checkNode', [ node[0], { silent: true}]);
                if(!this.multiple)break;//不能多选时，只选中第一个
                if(!(this.multiple && this.cascade))continue;//仅多选，且可延展选择时操作
                var tempNode = node[0];
                while(true)
                {
                    if(tempNode.parentId != undefined)
                    {
                        //有父节点
                        //选定该节点，再找其父节点
                        var pNode = Tree.treeview('getNode', [tempNode.parentId, {ignoreCase: true, exactMatch: false}]);
                        //选中该父节点
                        Tree.treeview('checkNode', [ pNode, { silent: true}]);
                        tempNode = pNode;
                    }
                    else
                    {
                        break;
                    }
                }

            }
        }
        if (text.length == 0) {
        	if(this.showTextOnButton){
        		Button[0].innerHTML = opt.defaultLable + '<span class="caret"></span>';
        		Button.attr("title", opt.defaultLable);
        	}
        	Text.val('').attr("title", '');
        }
        else {
            if (text.length <= opt.maxItemsDisplay) {
            	if(this.showTextOnButton){
            		Button[0].innerHTML = text + '<span class="caret"></span>';
            		Button.attr("title", text);
            	}
            	Text.val(_this.Text.join()).attr("title", _this.Text.join());
            }
            else {
            	if(this.showTextOnButton){
            		Button[0].innerHTML = text.length + '项被选中 <span class="caret"></span>';
            		Button.attr("title", text.length + '项被选中');
            	}
            	Text.val(_this.Text.join()).attr("title", _this.Text.join());
            }
        }
        hidden.val(value);
    }

    $.fn.bootstrapCombotree.methods = {
        getValue : function (target) {
            return $(target).data("bootstrapCombotree").toString();//隐藏域
        }
    }
})(jQuery);