$.validator.config({
    rules: {
        mobile: [/^1[3-9]\d{9}$/, "请填写有效的手机号"],
        chinese: [/^[\u0391-\uFFE5]+$/, "请填写中文字符"],
        idcard: [/^\d{15}(\d{2}[A-Za-z0-9])?$/,'身份证号码格式不正确']
    }
});